#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iomanip>

using namespace std;

typedef struct
{
	int main, kend, buka,cari,caripeny,sort,sortby,order;
}pilih;
pilih menu;

typedef struct
{
	int tgl, bln, thn;
}data_tanggal;

typedef struct
{
	int denda, terlambat, byrdenda;
	data_tanggal hrskembali, kembali;
}data3;
data3 pengembalian[20];

typedef struct
{
	char nama[20], nik[20], alamat[50];
	int lama, total, bayar, kembalian, no;
	data_tanggal nyewa;
}data2;
data2 sewa[20],temp[20];

typedef struct 
{
	char merk[20][20];
	int biaya[20], stok[20], banyak, total;
}data;
data kendaraan[2];//, disewa[2];

string yn, kategori;
int datawal[2],penyewa,kn[20];
int hari[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
char file[20];
char txt[]=".txt";
char n[20]={'n','_','\0'};
char p[20]={'p','n','y','w','_','\0'};
char dsw[20]={'d','s','w','_','\0'};
char kmbl[20]={'k','m','b','l','_','\0'};
	
void judul();
void inputdata();
void bukadata();
void inputsewa();
void kuitansi();
void cetak_tanggal(int D, int M, int Y);
void transaksi();
void bukapenyewa();
void mengembalikan();
void carikend(), caripeny();
void searching();
void sorting();
void sort_kend(), sort_peny();
void quick_sort(int first, int last),selection_sort();;
void bukafile();

FILE *fkend, *fn, *fpenyewa, *fkembali, *fdisewa;

int main()
{
	kendaraan[0].banyak=0; kendaraan[1].banyak=0; kendaraan[0].total=0; kendaraan[1].total=0; penyewa=0;
	cout << "Masukkan nama file (tanpa format file): ";
	cin.getline(file,sizeof(file));
	strcat(file,txt); //file.txt
	strcat(n,file);
	strcat(p,file);
	strcat(dsw,file);
	strcat(kmbl,file);
	if((fkend=fopen(file,"rb"))==NULL)
	{
		fkend=fopen(file,"wb");
		fn=fopen(n,"wb");
		putw(penyewa,fn);
		fclose(fn);
		datawal[0]=0; datawal[1]=0;
	}
	else
	{
		fread(&kendaraan,sizeof(kendaraan),1,fkend);
		fclose(fkend);
		fn=fopen(n,"rb");
		penyewa=getw(fn);
		fclose(fn);
		fdisewa=fopen(dsw,"rb");
		for(int i=0; i<penyewa; i++){
			kn[i]=getw(fdisewa);
		}
		fclose(fdisewa);
		fpenyewa=fopen(p,"rb");
		fread(&sewa,sizeof(sewa),1,fpenyewa);
		fclose(fpenyewa);
		fkembali=fopen(kmbl,"rb");
		fread(&pengembalian,sizeof(pengembalian),1,fkembali);
		fclose(fkembali);
	}
	do{
		judul();

		cout<<"\n1. Input Data Kendaraan";
		cout<<"\n2. Penyewaan";
		cout<<"\n3. Pengembalian";
		cout<<"\n4. Buka Data";
		cout<<"\n5. Searching Data";
		cout<<"\n6. Sorting Data";
		cout<<"\n7. EXIT";
		cout<<"\nPilih menu : ";
		cin>>menu.main;
		system("cls");
		switch(menu.main)
		{
			case 1:
			judul();
			cout<<"=== INPUT DATA KENDARAAN ===\n";
			inputdata();
			break;
			
			case 2:
			judul();
			cout<<"=== SEWA KENDARAAN ===\n";
			inputsewa();
			break;
			
			case 3:
			judul();
			cout << "=== PENGEMBALIAN KENDARAAN ===\n";
			mengembalikan();
			break;
			
			case 4:
			judul();
			cout << "=== BUKA DATA ===\n";
			cout << "1. Data Kendaraan\n";
			cout << "2. Data Penyewa\n";
			cout << "3. Kembali ke menu utama\n";
			cout << "Pilih : "; cin >> menu.buka;
			switch(menu.buka){
				case 1:
				judul();
				cout<<"=== DATA KENDARAAN ===\n";
				bukadata();
				break;
				
				case 2:
				judul();
				cout << "\n\n=== DATA PENYEWA ===\n\n";
				bukapenyewa();
				case 3:
				break;
			}
			break;
			
			case 5:
			do{
				judul();
				cout << "=== SEARCHING ===\n";
				cout << "1. Cari Kendaraan\n";
				cout << "2. Cari Penyewa\n";
				cout << "3. Kembali ke menu utama\n";
				cout << "Pilih : "; cin >> menu.cari;
				switch(menu.cari){
					case 1:
					judul();
					carikend();
					break;
					
					case 2:
					judul();
					caripeny();
					break;
					
					case 3:
					break;
				}
				if(menu.kend!=2 && menu.cari!=3 && menu.caripeny!=3){
					do{
						cout << "Apakah ingin kembali ke menu searching?(y/n): "; 
						cin >> yn;
					}while((yn!="y" && yn !="Y") && (yn !="n" && yn!="N"));
				}
				else if(menu.cari==3){
				yn="n";
				}
				else {
				yn="y"; menu.kend=0; menu.caripeny=0;
				}
			}while(yn=="y" || yn=="Y");
			break;
			
			case 6:
			judul();
			cout << "=== SORTING ===\n";
			sorting();
			break;
			
			
		}
		if(menu.kend!=2 && menu.buka!=3 && menu.cari!=3){
			do{
				cout << "Apakah ingin kembali ke menu utama?(y/n): "; cin >> yn;
			}while((yn!="y" && yn !="Y") && (yn !="n" && yn!="N"));
		}
		else {
			yn="y"; menu.kend=0; menu.buka=0; menu.cari=0;
		}
	}while(yn=="y" || yn=="Y");
		
}

void judul(){
	system("cls");
	cout << " " << setfill('-') << setw(72) << " " << endl;
	cout << "|	P E R S E W A A N  K E N D A R A A N	|" << endl;
	cout << " " << setfill('-') << setw(72) << " " << endl << endl;
}

void inputdata(){
	int n, tambah, plustok;
	string kategori;
	datawal[0]=kendaraan[0].banyak;datawal[1]=kendaraan[1].banyak;
	do{
		cout<<"1.Mobil\n";
		cout<<"2.Motor\n";
		cout<<"3.Kembali ke menu utama\n";
		cout<<"Pilih: "; cin>> menu.kend;
	}while(menu.kend<1 || menu.kend>3);
	menu.kend=menu.kend-1;
	if(menu.kend==0) kategori = "mobil";
	else if(menu.kend==1) kategori = "motor";
	if(menu.kend!=2){
		if(kendaraan[menu.kend].banyak==0){
			do{
				cout<<"\nMasukkan banyak kendaraan " << kategori << " : ";
				cin>>n;
				if(n<0)
					cout << "Tidak dapat kurang dari 0 oi...\n";
			}while(n<0);
			kendaraan[menu.kend].banyak=kendaraan[menu.kend].banyak+n;
		}
		else{
			for (int i = 0; i < kendaraan[menu.kend].banyak; i++)
			{
				cout<< endl << kategori <<" no. "<<i+1<<endl;
				cout<<"Merk "<<kategori<<" : " << kendaraan[menu.kend].merk[i] << endl;
				cout<<"Banyak "<<kategori<<" "<<kendaraan[menu.kend].merk[i]<<" : "<< kendaraan[menu.kend].stok[i] << endl;
				cout<<"Biaya sewa/ Hari : "<< kendaraan[menu.kend].biaya[i] << endl;
			}
			
			cout << "\n1. Tambah kendaraan " << kategori;
			cout << "\n2. Tambah stok " << kategori << " yang sudah ada";
			cout << "\nPilih : "; cin >> tambah;
			cout << endl;
			if(tambah==1){
				do{
					cout << "Masukkan banyak tambahan kendaraan "<< kategori << " = "; 
					cin>>n;
					if(n<0)
						cout << "Tidak dapat kurang dari 0 oi...\n";
				}while(n<0);
				kendaraan[menu.kend].banyak=kendaraan[menu.kend].banyak+n;
			}
			else if(tambah==2){
				for(int i=0; i<kendaraan[menu.kend].banyak; i++){
					cout << i+1 << ". Tambah stok " << kategori << " " << kendaraan[menu.kend].merk[i];
					cout << endl;
				}
				cout << "\nPilih : "; cin >> tambah;
				tambah--;
				do{
					cout << "Masukkan banyak tambahan stok " << kategori << " " << kendaraan[menu.kend].merk[tambah];
					cout << " = "; cin >> plustok;
					if(plustok<0)
						cout << "Tidak dapat kurang dari 0 oi...\n";
				}while(plustok<0); 
				kendaraan[menu.kend].stok[tambah]=kendaraan[menu.kend].stok[tambah]+plustok;
				kendaraan[menu.kend].total=kendaraan[menu.kend].total+plustok;
			}
		}
		fkend = fopen(file,"wb");
		cout << endl;
		for (int i = datawal[menu.kend]; i < kendaraan[menu.kend].banyak; i++)
		{
			cin.ignore();
			cout<<"Data "<< kategori <<" ke-"<<i+1<<endl;
			cout<<"Merk "<<kategori<<" : ";
			cin.getline(kendaraan[menu.kend].merk[i], 20);
			cout<<"Banyak "<<kategori<<" "<<kendaraan[menu.kend].merk[i]<<" : ";
			cin>>kendaraan[menu.kend].stok[i];
			cout<<"Biaya sewa/ Hari : ";
			cin>>kendaraan[menu.kend].biaya[i];
			cout << endl;
			kendaraan[menu.kend].total=kendaraan[menu.kend].total+kendaraan[menu.kend].stok[i];
		}
		fwrite(&kendaraan,sizeof(kendaraan),1,fkend);
		fclose(fkend);
	}
}

void bukadata()
{
	do{
		fkend = fopen(file,"rb");
		fread(&kendaraan,sizeof(kendaraan),1,fkend);
		fclose(fkend);
		cout<<"1.Mobil\n";
		cout<<"2.Motor\n";
		cout<<"3.Kembali ke menu utama\n";
		cout<<"Pilih: "; cin>> menu.kend;
	}while(menu.kend<1 || menu.kend>3);
	menu.kend=menu.kend-1;
	if(menu.kend==0) kategori = "mobil";
	 else if(menu.kend==1) kategori = "motor";
	if(menu.kend!=2){
		system("cls");
		cout << "===== Daftar Kendaraan =====\n";
		cout<<"Kendaraan " << kategori << " yang tersedia untuk disewa : " << kendaraan[menu.kend].total << endl;
		
		for (int i = 0; i < kendaraan[menu.kend].banyak; i++)
		{
			cout<< endl << kategori <<" no. "<<i+1<<endl;
			cout<<"Merk "<<kategori<<" : " << kendaraan[menu.kend].merk[i] << endl;
			cout<<"Banyak "<<kategori<<" "<<kendaraan[menu.kend].merk[i]<<" : "<< kendaraan[menu.kend].stok[i] << endl;
			cout<<"Biaya sewa/ Hari : "<< kendaraan[menu.kend].biaya[i] << endl;
		}
	}
}

void inputsewa()
{
	bool found;
	do{
		bukadata();
		if(kendaraan[menu.kend].total>0 && menu.kend!=2){
			do{
				do{
					fpenyewa=fopen(p,"rb");
					fread(&sewa,sizeof(sewa),1,fpenyewa);
					fclose(fpenyewa);
					fkembali=fopen(kmbl,"rb");
					fread(&pengembalian,sizeof(pengembalian),1,fkembali);
					fclose(fkembali);
					cout << "\n===== Data penyewa =====\n";
					cout << "Penyewa " << penyewa+1 << ".\n";
					cout << "Nama	: "; cin.ignore();cin.getline(sewa[penyewa].nama,20);
					do{
						cout << "NIK	: "; cin.getline(sewa[penyewa].nik,20);
						int i=penyewa; found = false;
						while(i>0 && !found){
							if(strcmp(sewa[penyewa].nik,sewa[i-1].nik)==0){
								cout << "NIK sudah dipakai dan belum mengembalikan sewaan\n";
								found=true;
							}
							else
								i--;
						}
					}while(found);
					cout << "Alamat	: "; cin.getline(sewa[penyewa].alamat,20);
					do{
						cout << "Pilih " << kategori << " no : "; cin >> sewa[penyewa].no;
						sewa[penyewa].no=sewa[penyewa].no-1;
						if(sewa[penyewa].no<0||sewa[penyewa].no>=kendaraan[menu.kend].banyak)
							cout << "Pilihan tidak ada.\n";
						else if(kendaraan[menu.kend].stok[sewa[penyewa].no]==0)
							cout << "Stok habis.\n";
					}while((sewa[penyewa].no<0||sewa[penyewa].no>=kendaraan[menu.kend].banyak)||kendaraan[menu.kend].stok[sewa[penyewa].no]==0);
					cout << "Biaya sewa "<< kategori << " " << kendaraan[menu.kend].merk[sewa[penyewa].no] 
					<< " per hari = " << kendaraan[menu.kend].biaya[sewa[penyewa].no] << endl;
					do{
						cout << "Sewa berapa hari = "; cin >> sewa[penyewa].lama;
						if(sewa[penyewa].lama<1)
							cout << "Minimal sewa 1 hari\n";
					}while(sewa[penyewa].lama<1);
					sewa[penyewa].total=kendaraan[menu.kend].biaya[sewa[penyewa].no]*sewa[penyewa].lama;
					cout << "Total yang harus dibayar = " << sewa[penyewa].total << endl;
					do{
						cout << "Bayar = "; cin >> sewa[penyewa].bayar;
						if(sewa[penyewa].bayar<sewa[penyewa].total)
							cout << "Gagal! Pembayaran kurang.\n";
					}while(sewa[penyewa].bayar<sewa[penyewa].total);
					sewa[penyewa].kembalian=sewa[penyewa].bayar-sewa[penyewa].total;

					do{
						do{
							do{
								yn="n";
								cout << "Tanggal sewa (DD/MM/YYYY) = "; 
								cin >> sewa[penyewa].nyewa.tgl;
								if(cin.get()!='/'){
									cout << "Pakai slash (/) untuk pemisah\n";
									yn="y";
								}
							}while(yn=="y");
							cin >> sewa[penyewa].nyewa.bln;
							if(cin.get()!='/'){
								cout << "Pakai slash (/) untuk pemisah\n";
								yn="y";
							}
						}while(yn=="y");
						cin >> sewa[penyewa].nyewa.thn;
						if(sewa[penyewa].nyewa.tgl<1 || sewa[penyewa].nyewa.tgl>31){
							cout << "Tanggal tidak valid\n";
							yn="y";
						}
						if(sewa[penyewa].nyewa.bln<1 || sewa[penyewa].nyewa.bln>12){
							cout << "Bulan tidak valid\n";
							yn="y";
						}
					}while(yn=="y");
					pengembalian[penyewa].hrskembali.tgl = sewa[penyewa].nyewa.tgl + sewa[penyewa].lama;
					pengembalian[penyewa].hrskembali.bln = sewa[penyewa].nyewa.bln;
					pengembalian[penyewa].hrskembali.thn = sewa[penyewa].nyewa.thn;
					if(pengembalian[penyewa].hrskembali.tgl>hari[pengembalian[penyewa].hrskembali.bln]){
						pengembalian[penyewa].hrskembali.tgl=pengembalian[penyewa].hrskembali.tgl-hari[pengembalian[penyewa].hrskembali.bln];
						pengembalian[penyewa].hrskembali.bln++;
					}
					if(pengembalian[penyewa].hrskembali.bln>12){
						pengembalian[penyewa].hrskembali.bln=pengembalian[penyewa].hrskembali.bln-12;
						pengembalian[penyewa].hrskembali.thn++;
					}
					do{
						cout << "Apakah pengisian data sudah benar?(y/n) : "; cin >> yn;
					}while((yn!="y" && yn !="Y") && (yn !="n" && yn!="N"));
				}while(yn=="n" || yn=="N");
				fpenyewa=fopen(p,"wb");
				fwrite(&sewa,sizeof(sewa),1,fpenyewa);
				fclose(fpenyewa);
				fkembali=fopen(kmbl,"wb");
				fwrite(&pengembalian,sizeof(pengembalian),1,fkembali);
				fclose(fkembali);
				kuitansi();
				fn=fopen(n,"wb");
				penyewa++;
				putw(penyewa,fn);
				fclose(fn);
				fdisewa=fopen(dsw,"ab");
				putw(menu.kend,fdisewa);
				fclose(fdisewa);
				do{
					cout << "Masukkan data penyewa lagi?(y/n) : "; cin >> yn;
				}while((yn!="y" && yn !="Y") && (yn !="n" && yn!="N"));
			}while(yn=="y" || yn=="Y");
		}
		if(menu.kend!=2){
			do{
				cout << "Kembali ke menu penyewaan?(y/n) : "; cin >> yn;
			}while((yn!="y" && yn !="Y") && (yn !="n" && yn!="N"));
		}
		else yn="n";
	}while(yn=="y" || yn=="Y");
	
}

void kuitansi()
{
	
	cout << "\n\n======= KUITANSI =======\n\n";
	cout << "Nama			: " << sewa[penyewa].nama << endl;
	cout << "NIK			: " << sewa[penyewa].nik << endl;
	cout << "Alamat			: " << sewa[penyewa].alamat << endl;
	cout << "Mobil yang disewa	: " << kendaraan[menu.kend].merk[sewa[penyewa].no] << endl;
	cout << "Biaya sewa		: " << kendaraan[menu.kend].biaya[sewa[penyewa].no] << endl;
	cout << "Lama sewa		: " << sewa[penyewa].lama << endl;
	cout << "Total biaya		: " << sewa[penyewa].total << endl;
	cout << "Bayar			: " << sewa[penyewa].bayar << endl;
	cout << "Kembalian		: " << sewa[penyewa].kembalian << endl;
	cout << "Tanggal sewa		: "; cetak_tanggal(sewa[penyewa].nyewa.tgl,sewa[penyewa].nyewa.bln,sewa[penyewa].nyewa.thn);
	cout << "Maksimal kembali tanggal: "; 
	cetak_tanggal(pengembalian[penyewa].hrskembali.tgl,pengembalian[penyewa].hrskembali.bln,pengembalian[penyewa].hrskembali.thn);
	cout << "\n\nCatatan: \nPengembalian terlambat 1 hari, bayar 1 hari sewa (dan kelipatan) + denda 5%\n";
	transaksi();
	system("pause");
}

void transaksi()
{
	kendaraan[menu.kend].stok[sewa[penyewa].no]--;
	kendaraan[menu.kend].total--;
	fkend=fopen(file,"wb");
	fwrite(&kendaraan,sizeof(kendaraan),1,fkend);
	fclose(fkend);
}

void bukapenyewa()
{
	fdisewa=fopen(dsw,"rb");
	for(int i=0; i<penyewa; i++){
		menu.kend=getw(fdisewa);
		if(menu.kend==0) kategori = "Mobil";
		else if(menu.kend==1) kategori = "Motor";
		cout << i+1 << "." << endl;
		cout << "Nama			: " << sewa[i].nama << endl;
		cout << "NIK			: " << sewa[i].nik << endl;
		cout << "Alamat			: " << sewa[i].alamat << endl;
		cout << kategori << " yang disewa	: " << kendaraan[menu.kend].merk[sewa[i].no] << endl;
		cout << "Biaya sewa		: " << kendaraan[menu.kend].biaya[sewa[i].no] << endl;
		cout << "Lama sewa		: " << sewa[i].lama << endl;
		cout << "Total biaya		: " << sewa[i].total << endl;
		cout << "Bayar			: " << sewa[i].bayar << endl;
		cout << "Kembalian		: " << sewa[i].kembalian << endl;
		cout << "Tanggal sewa		: "; cetak_tanggal(sewa[i].nyewa.tgl,sewa[i].nyewa.bln,sewa[i].nyewa.thn);
		cout << "Maksimal kembali tanggal: "; 
		cetak_tanggal(pengembalian[i].hrskembali.tgl,pengembalian[i].hrskembali.bln,pengembalian[i].hrskembali.thn);
		cout << endl;
	}
	fclose(fdisewa);
}

void mengembalikan()
{
	char cari[20];
	bool found;
	int i=penyewa-1,k, selbln,selthn;
	
	fpenyewa=fopen(p,"rb");
	fread(&sewa,sizeof(sewa),1,fpenyewa);
	fclose(fpenyewa);
	fkembali=fopen(kmbl,"rb");
	fread(&pengembalian,sizeof(pengembalian),1,fkembali);
	fclose(fkembali);
	cin.ignore();
	cout << "Masukkan NIK : "; cin.getline(cari,20);
	found=false;
	while(i>=0 && !found){
		if(strcmp(cari,sewa[i].nik)==0)
			found = true;
		else
			i--;
	}
	if(!found){
		cout << "NIK tidak ditemuka.\n";
	}
	else{
		cout << "Nama			: " << sewa[i].nama << endl;
		cout << "NIK			: " << sewa[i].nik << endl;
		cout << "Alamat			: " << sewa[i].alamat << endl;
		cout << "Mobil yang disewa	: " << kendaraan[kn[i]].merk[sewa[i].no] << endl;
		cout << "Biaya sewa		: " << kendaraan[kn[i]].biaya[sewa[i].no] << endl;
		cout << "Lama sewa		: " << sewa[i].lama << endl;
		cout << "Total biaya		: " << sewa[i].total << endl;
		cout << "Bayar			: " << sewa[i].bayar << endl;
		cout << "Kembalian		: " << sewa[i].kembalian << endl;
		cout << "Tanggal sewa		: "; cetak_tanggal(sewa[i].nyewa.tgl,sewa[i].nyewa.bln,sewa[i].nyewa.thn);
		cout << "Maksimal kembali tanggal: "; 
		cetak_tanggal(pengembalian[i].hrskembali.tgl,pengembalian[i].hrskembali.bln,pengembalian[i].hrskembali.thn);
		do{
			do{
				do{
					yn="n";
					cout << "Tanggal pengembalian (DD/MM/YYYY) = "; 
					cin >> pengembalian[i].kembali.tgl;
					if(cin.get()!='/'){
						cout << "Pakai slash (/) untuk pemisah\n";
						yn="y";
					}
				}while(yn=="y");
				cin >> pengembalian[i].kembali.bln;
				if(cin.get()!='/'){
					cout << "Pakai slash (/) untuk pemisah\n";
					yn="y";
				}
			}while(yn=="y");
			cin >> pengembalian[i].kembali.thn;
			if(pengembalian[i].kembali.tgl<1 || pengembalian[i].kembali.tgl>31){
				cout << "Tanggal tidak valid\n";
				yn="y";
			}
			if(pengembalian[i].kembali.bln<1 || pengembalian[i].kembali.bln>12){
				cout << "Bulan tidak valid\n";
				yn="y";
			}
			if(pengembalian[i].kembali.thn<sewa[i].nyewa.thn){
				cout << "Tahun tidak valid. Mesin waktu belum ditemukan.\n";
				yn="y";
			}
				else if(pengembalian[i].kembali.bln<sewa[i].nyewa.bln && pengembalian[i].kembali.thn==sewa[i].nyewa.thn){
					cout << "Bulan tidak valid. Mesin waktu belum ditemukan.\n";
					yn="y";
				}
					else if(pengembalian[i].kembali.tgl<sewa[i].nyewa.tgl && pengembalian[i].kembali.bln==sewa[i].nyewa.bln){
						cout << "Tanggal tidak valid. Mesin waktu belum ditemukan.\n";
						yn="y";
						}
		}while(yn=="y");
		if(pengembalian[i].kembali.thn<=pengembalian[i].hrskembali.thn){
			if(pengembalian[i].kembali.bln<=pengembalian[i].hrskembali.bln){
				if(pengembalian[i].kembali.tgl<=pengembalian[i].hrskembali.tgl){
					pengembalian[i].terlambat=0;
				}
				else if(pengembalian[i].kembali.tgl>pengembalian[i].hrskembali.tgl){
					pengembalian[i].terlambat=pengembalian[i].kembali.tgl-pengembalian[i].hrskembali.tgl;
				}
			}
			else if(pengembalian[i].kembali.bln>pengembalian[i].hrskembali.bln){
				pengembalian[i].terlambat=0;
				for(int j=pengembalian[i].hrskembali.bln; j<pengembalian[i].kembali.bln; j++){
					pengembalian[i].terlambat=pengembalian[i].terlambat+hari[j];
				}
				pengembalian[i].terlambat=(pengembalian[i].terlambat+pengembalian[i].kembali.tgl)-pengembalian[i].hrskembali.tgl;
			}
		}
		else{
			selthn=pengembalian[i].kembali.thn-pengembalian[i].hrskembali.thn;
			selbln=(pengembalian[i].kembali.bln+(12*selthn))-pengembalian[i].hrskembali.bln;
			pengembalian[i].terlambat=0;
			for(int j=pengembalian[i].hrskembali.bln; j<selbln; j++){
				if(j<=12)
					k=j;
				else if(j>12){
					k=j%12;
					if(k==0)
						k=12;
				}
				pengembalian[i].terlambat=pengembalian[i].terlambat+hari[k];
			}
			pengembalian[i].terlambat=(pengembalian[i].terlambat+pengembalian[i].kembali.tgl)-pengembalian[i].hrskembali.tgl;
		}
		if(pengembalian[i].terlambat==0){
			pengembalian[i].denda=0;
			cout << "Kendaraan " << kategori << " " << kendaraan[kn[i]].merk[sewa[i].no] << " telah dikembalikan tepat waktu.\n";
		}
		else{
			pengembalian[i].denda=(pengembalian[i].terlambat*kendaraan[kn[i]].biaya[sewa[i].no]);
			pengembalian[i].denda=pengembalian[i].denda+(pengembalian[i].denda*5/100);
			cout << "Pengembalian terlambat " << pengembalian[i].terlambat << " hari.\n";
			cout << "Denda = Biaya sewa * keterlambatan + 5%\n";
			cout << "Denda = "<< kendaraan[kn[i]].biaya[sewa[i].no] << " * " << pengembalian[i].terlambat << " + 5%\n";
			cout << "Denda = "<< pengembalian[i].denda << endl;
			do{
				cout << "Bayar Denda = "; cin >> pengembalian[i].byrdenda;
				if(pengembalian[i].byrdenda<pengembalian[i].denda)
					cout << "Gagal! Pembayaran kurang.\n";
			}while(pengembalian[i].byrdenda<pengembalian[i].denda);
			cout << "Kembalian: " << pengembalian[i].byrdenda-pengembalian[i].denda << endl;
			cout << "=== LUNAS ===\n";
		}
		kendaraan[kn[i]].stok[sewa[i].no]++;
		kendaraan[kn[i]].total++;
		fkend=fopen(file,"wb");
		fwrite(&kendaraan,sizeof(kendaraan),1,fkend);
		fclose(fkend);
		
		
		fdisewa=fopen(dsw,"wb");
		for(int j=0; j<penyewa-i; j++){
			sewa[i]=sewa[i+1];
			pengembalian[i]=pengembalian[i+1];
			kn[i]=kn[i+1];
			putw(kn[i],fdisewa);
			i++;
		}
		fclose(fdisewa);

		fkembali=fopen(kmbl,"wb");
		fwrite(&pengembalian,sizeof(pengembalian),1,fkembali);
		fclose(fkembali);
		penyewa--;
		fn=fopen(n,"wb");
		putw(penyewa,fn);
		fclose(fn);
		for(int j=0; j<penyewa; j++){
			temp[j]=sewa[j];
		}

		fpenyewa=fopen(p,"wb");
		fwrite(&temp,sizeof(temp),1,fpenyewa);
		fclose(fpenyewa);
		cout << "\n\n===== TERIMA KASIH =====\n\n";
	}
}

void cetak_tanggal(int D, int M, int Y)
{
	char *nama_bln[] = { "\0", "Januari", "Februari", "Maret",
	"April", "Mei", "Juni", "Juli", "Agustus", "September",
	"Oktober", "November", "Desember" };
	cout << D << " / " << nama_bln[M]
	<< " / " << Y << endl;
}

void carikend()
{
	int plh;
	do{
		cout << "1. Cari Mobil\n";
		cout << "2. Cari Motor\n";
		cout << "3. Kembali ke menu searching\n";
		cout << "Pilih: "; cin >> plh;
	}while(plh<1 || plh>3);
	menu.kend=plh-1;
	if(menu.kend==0) kategori = "mobil";
	 else if(menu.kend==1) kategori = "motor";
	switch(plh){
		case 1:
		searching();
		break;
		case 2:
		searching();
		break;
		case 3:
		break;
	}
}

void caripeny()
{
	int nemu,j, ketemu[20];
	char cari[20];
	j=0; nemu=0;
	do{
		cout << "\n1. Cari nama";
		cout << "\n2. Cari NIK";
		cout << "\n3. Kembali ke menu searching\n";
		cout << "\nPilih: "; cin >> menu.caripeny;
	}while(menu.caripeny<1 || menu.caripeny>3);
	fdisewa=fopen(dsw,"rb");
	switch(menu.caripeny)
	{
		case 1:
		cout << "Masukkan nama penyewa: "; cin.ignore();
		cin.getline(cari,20);
		for(int i=0; i<penyewa; i++){
			kn[i]=getw(fdisewa);
			if(strcmp(cari,sewa[i].nama)==0){
				ketemu[j]=i;
				nemu++; j++;
			}
		}
		break;
		case 2:
		cout << "Masukkan NIK penyewa: "; cin.ignore();
		cin.getline(cari,20);
		for(int i=0; i<penyewa; i++){
			kn[i]=getw(fdisewa);
			if(strcmp(cari,sewa[i].nik)==0){
				ketemu[j]=i;
				nemu++; j++;
			}
		}
		break;
		case 3:
		break;
	}
	fclose(fdisewa);
	if(menu.caripeny==1 || menu.caripeny==2){
		if(nemu>0){
			
			for(int i=0; i<nemu; i++){
				if(kn[ketemu[i]]==0) kategori = "Mobil";
				else if(kn[ketemu[i]]==1) kategori = "Motor";
				cout << i+1 << "." << endl;
				cout << "Nama			: " << sewa[ketemu[i]].nama << endl;
				cout << "NIK			: " << sewa[ketemu[i]].nik << endl;
				cout << "Alamat			: " << sewa[ketemu[i]].alamat << endl;
				cout << kategori <<" yang disewa	: " << kendaraan[kn[ketemu[i]]].merk[sewa[ketemu[i]].no] << endl;
				cout << "Biaya sewa		: " << kendaraan[kn[i]].biaya[sewa[ketemu[i]].no] << endl;
				cout << "Lama sewa		: " << sewa[ketemu[i]].lama << endl;
				cout << "Total biaya		: " << sewa[ketemu[i]].total << endl;
				cout << "Bayar			: " << sewa[ketemu[i]].bayar << endl;
				cout << "Kembalian		: " << sewa[ketemu[i]].kembalian << endl;
				cout << "Tanggal sewa		: "; cetak_tanggal(sewa[ketemu[i]].nyewa.tgl,sewa[ketemu[i]].nyewa.bln,sewa[ketemu[i]].nyewa.thn);
				cout << "Maksimal kembali tanggal: "; 
				cetak_tanggal(pengembalian[ketemu[i]].hrskembali.tgl,pengembalian[ketemu[i]].hrskembali.bln,pengembalian[ketemu[i]].hrskembali.thn);
			}
		}
		else{
			if(menu.caripeny==1)
				cout << "Nama " << cari << " tidak ditemukan.\n";
			else
				cout << "NIK " << cari << " tidak ditemukan.\n";
		}
	}
}

void searching()
{
	int plh, atas, bawah;
	int nemu,j, ketemu[20];
	nemu=0; j=0;
	char cari[20];
	do{
		cout << "\n1. Cari merk " << kategori;
		cout << "\n2. Cari rentang biaya sewa " << kategori;
		cout << "\nPilih: "; cin >> plh;
	}while(plh!=1 && plh!=2);
	switch(plh){
		case 1:
		cout << "Masukkan merk " << kategori << ": "; cin.ignore();
		cin.getline(cari,20);
		for(int i=0; i<kendaraan[menu.kend].banyak; i++){
			if(strcmp(cari,kendaraan[menu.kend].merk[i])==0){
				ketemu[j]=i;
				nemu++; j++;
			}
		}
		if(nemu>0){
			for(int i=0; i<nemu; i++){
				cout<< endl << kategori <<" no. "<<i+1<<endl;
				cout<<"Merk "<<kategori<<" : " << kendaraan[menu.kend].merk[ketemu[i]] << endl;
				cout<<"Banyak "<<kategori<<" "<<kendaraan[menu.kend].merk[ketemu[i]]<<" yang tersedia : "<< kendaraan[menu.kend].stok[ketemu[i]] << endl;
				cout<<"Biaya sewa/ Hari : "<< kendaraan[menu.kend].biaya[ketemu[i]] << endl;
			}
		}
		else
			cout << "Merk " << kategori << " " << cari << " tidak ditemukan.\n";
		break;
		
		case 2:
		do{
			cout << "Masukkan batas bawah biaya sewa " << kategori << ": ";
			cin >> bawah;
			cout << "Masukkan batas atas biaya sewa " << kategori << ": ";
			cin >> atas;
			if(bawah>atas)
				cout << "Batas atas harus lebih besar dari batas bawah.\n";
		}while(bawah>atas);
		for(int i=0; i<kendaraan[menu.kend].banyak; i++){
			if(kendaraan[menu.kend].biaya[i]>=bawah && kendaraan[menu.kend].biaya[i]<=atas){
				ketemu[j]=i;
				nemu++; j++;
			}
		}
		if(nemu>0){
			cout << "Kendaraan " << kategori << " dengan rentang biaya sewa " << bawah << " - " << atas << endl;
			cout << "Ditemukan sebanyak " << nemu << " data." << endl;
			for(int i=0; i<nemu; i++){
				cout<< endl << kategori <<" no. "<<i+1<<endl;
				cout<<"Merk "<<kategori<<" : " << kendaraan[menu.kend].merk[ketemu[i]] << endl;
				cout<<"Banyak "<<kategori<<" "<<kendaraan[menu.kend].merk[ketemu[i]]<<" : "<< kendaraan[menu.kend].stok[ketemu[i]] << endl;
				cout<<"Biaya sewa/ Hari : "<< kendaraan[menu.kend].biaya[ketemu[i]] << endl;
			}
		}
		else{
			cout << "Kendaraan " << kategori << " dengan rentang biaya sewa " << bawah << " - " << atas << endl;
			cout << "Tidak ditemukan.\n";
		}
	}
}

void sorting()
{
	cout <<"\n1. Sorting kendaraan";
	cout <<"\n2. Sorting penyewa";
	cout <<"\nPilih: "; cin >> menu.sort;
	switch(menu.sort)
	{
		case 1:
		sort_kend();
		break;
		
		case 2:
		sort_peny();
	}
}

void sort_kend()
{
	do{
		cout << "\n1. Sorting mobil";
		cout << "\n2. Sorting motor";
		cout << "\nPilih: "; cin >> menu.kend;
	}while(menu.kend!=1 && menu.kend!=2);
	menu.kend=menu.kend-1;
	if(menu.kend==0) kategori = "mobil";
	 else if(menu.kend==1) kategori = "motor";
	
	cout << "\n1. Sorting " << kategori <<" berdasarkan merk";
	cout << "\n2. Sorting " << kategori <<" berdasarkan biaya sewa";
	cout << "\nPilih: "; cin >> menu.sortby;
	cout << "\n1. Dari kecil ke besar (ascending)";
	cout << "\n2. Dari besar ke kecil (descending)";
	cout << "\nPilih: "; cin >> menu.order;
	
	quick_sort(0,kendaraan[menu.kend].banyak-1);
	for (int i = 0; i < kendaraan[menu.kend].banyak; i++)
	{
		cout<< endl << kategori <<" no. "<<i+1<<endl;
		cout<<"Merk "<<kategori<<" : " << kendaraan[menu.kend].merk[i] << endl;
		cout<<"Banyak "<<kategori<<" "<<kendaraan[menu.kend].merk[i]<<" : "<< kendaraan[menu.kend].stok[i] << endl;
		cout<<"Biaya sewa/ Hari : "<< kendaraan[menu.kend].biaya[i] << endl;
	}
	bukafile();
}

void sort_peny()
{
	fdisewa=fopen(dsw,"rb");
	for(int i=0; i<penyewa; i++){
		kn[i]=getw(fdisewa);
	}
	fclose(fdisewa);
	cout << "\n1. Sorting berdasarkan nama";
	cout << "\n2. Sorting berdasarkan NIK";
	cout << "\nPilih: "; cin >> menu.sortby;
	cout << "\n1. Dari kecil ke besar (ascending)";
	cout << "\n2. Dari besar ke kecil (descending)";
	cout << "\nPilih: "; cin >> menu.order;
	selection_sort();
	
	for(int i=0; i<penyewa; i++){
		if(kn[i]==0) kategori = "Mobil";
		else if(kn[i]==1) kategori = "Motor";
		cout << i+1 << "." << endl;
		cout << "Nama			: " << sewa[i].nama << endl;
		cout << "NIK			: " << sewa[i].nik << endl;
		cout << "Alamat			: " << sewa[i].alamat << endl;
		cout << kategori <<" yang disewa	: " << kendaraan[kn[i]].merk[sewa[i].no] << endl;
		cout << "Biaya sewa		: " << kendaraan[kn[i]].biaya[sewa[i].no] << endl;
		cout << "Lama sewa		: " << sewa[i].lama << endl;
		cout << "Total biaya		: " << sewa[i].total << endl;
		cout << "Bayar			: " << sewa[i].bayar << endl;
		cout << "Kembalian		: " << sewa[i].kembalian << endl;
		cout << "Tanggal sewa		: "; cetak_tanggal(sewa[i].nyewa.tgl,sewa[i].nyewa.bln,sewa[i].nyewa.thn);
		cout << "Maksimal kembali tanggal: "; 
		cetak_tanggal(pengembalian[i].hrskembali.tgl,pengembalian[i].hrskembali.bln,pengembalian[i].hrskembali.thn);
	}
	bukafile();
}

void quick_sort(int first, int last)
{
	int low, high,l_separator;
	char list_separator[20];
	low = first;
	high = last;
	strcpy(list_separator,kendaraan[menu.kend].merk[(first+last)/2]);
	l_separator=kendaraan[menu.kend].biaya[(first+last)/2];
	do {
		if(menu.sortby==1){
			if(menu.order==1){//ascendingorder
				while(strcmp(kendaraan[menu.kend].merk[low],list_separator) < 0)
				low++;
				while(strcmp(kendaraan[menu.kend].merk[high],list_separator) > 0)
				high--;
			}
			else{//descendingorder
				while(strcmp(kendaraan[menu.kend].merk[low],list_separator) > 0)
				low++;
				while(strcmp(kendaraan[menu.kend].merk[high],list_separator) < 0)
				high--;
			}
		}
		else{
			if(menu.order==1){//ascendingorder
				while(kendaraan[menu.kend].biaya[low] < l_separator)
				low++;
				while(kendaraan[menu.kend].biaya[high] > l_separator)
				high--;
			}
			else{//descendingorder
				while(kendaraan[menu.kend].biaya[low] > l_separator)
				low++;
				while(kendaraan[menu.kend].biaya[high] < l_separator)
				high--;
			}
		}
		if(low <= high)
		{
			swap(kendaraan[menu.kend].merk[low],kendaraan[menu.kend].merk[high]);
			swap(kendaraan[menu.kend].biaya[low],kendaraan[menu.kend].biaya[high]);
			swap(kendaraan[menu.kend].stok[low],kendaraan[menu.kend].stok[high]);
			low++; high--;
		}
	} while(low <= high);
	if(first < high) quick_sort(first, high);
	if(low < last) quick_sort(low, last);
}

void selection_sort()
{
	for(int i=0; i<penyewa; i++){		
		for(int j=i+1; j<penyewa; j++){
			if(menu.sortby==1){
				if(menu.order==1){//ascendingorder
					if(strcmp(sewa[i].nama,sewa[j].nama) > 0){
						swap(sewa[i],sewa[j]);
						swap(kn[i],kn[j]);
						swap(pengembalian[i],pengembalian[j]);
					}
				}
				else{//descendingorder
					if(strcmp(sewa[i].nama,sewa[j].nama) < 0){
						swap(sewa[i],sewa[j]);
						swap(kn[i],kn[j]);
						swap(pengembalian[i],pengembalian[j]);
					}
				}
			}
			else{
				if(menu.order==1){//ascendingorder
					if(strcmp(sewa[i].nik,sewa[j].nik) > 0){
						swap(sewa[i],sewa[j]);
						swap(kn[i],kn[j]);
						swap(pengembalian[i],pengembalian[j]);
					}
				}
				else{//descendingorder
					if(strcmp(sewa[i].nik,sewa[j].nik) < 0){
						swap(sewa[i],sewa[j]);
						swap(kn[i],kn[j]);
						swap(pengembalian[i],pengembalian[j]);
					}
				}
			}
		}
	}
}


void bukafile()
{
	fkend=fopen(file,"rb");
	fread(&kendaraan,sizeof(kendaraan),1,fkend);
	fclose(fkend);
	fn=fopen(n,"rb");
	penyewa=getw(fn);
	fclose(fn);
	fpenyewa=fopen(p,"rb");
	fread(&sewa,sizeof(sewa),1,fpenyewa);
	fclose(fpenyewa);
	fkembali=fopen(kmbl,"rb");
	fread(&pengembalian,sizeof(pengembalian),1,fkembali);
	fclose(fkembali);
	fdisewa=fopen(dsw,"rb");
	for(int i=0; i<penyewa; i++){
		kn[i]=getw(fdisewa);
	}
	fclose(fdisewa);
}
