// Project Akhir Penilaian Mahasiswa
// Totti Andra 123180094
// Achmad Syahrul Hanafi 123180112

#include <iostream>
#include <iomanip>
#include <stdlib.h>
#include <string.h>

using namespace std;

void title(){
	//judul
	cout << " " << setfill('-') << setw(72) << " " << endl;
	cout << "|	Program Penilaian Mahasiswa FTI UPN \"Veteran\" Yogyakarta	|" << endl;
	cout << " " << setfill('-') << setw(72) << " " << endl << endl;
}

int main()
{
	title();
	
	char nama[30];
	char nim[30];
	string grade[20];
	char matkul[20][20];
	char yn;
	int i=0;
	int menu, a, pilih, pilihan;
	int jumatkul=0;
	float quiz[20], aktif[20], tugas[20], uts[20], uas[20], hadir[20];
	float pquiz[20], paktif[20], ptugas[20], puts[20], puas[20];
	float phadir[20], ptotal[20], absen[20], akhir[20];
	
	do{
	system ("cls");
	title();
	cout << "Program Penilaian Mahasiswa" << endl;
	cout << setfill('-') << setw(27) << "-" << endl;
	cout << "Menu: " << endl;
	cout << "1. Input Data" << endl;
	cout << "2. Output Data" << endl;
	cout << "0. Exit" << endl;
	cout << "Pilihan: "; cin >> menu;
	
	switch(menu){
		case 1: 
		pilih=2; //untuk input oleh orang baru
		if (jumatkul>0){
			pilih=0;
			while (pilih!=1 && pilih!=2){
			system ("cls");
			title();
			cout << "1. Input sebagai " << nama << endl;
			cout << "2. Input sebagai orang baru" << endl;
			cout << "Pilih: "; cin >> pilih;
			if (pilih == 1){
				pilihan=0;
				while (pilihan!=1 && pilihan!=2){
				cout << "1. Lanjutkan data" << endl;
				cout << "2. Reset data" << endl; 
				cout << "Pilih: "; cin >> pilihan;
				if (pilihan==1) jumatkul++;
					else if (pilihan==2) {
						jumatkul=0; i=0;}
					else if (pilihan!=1 || pilihan!=2) continue;
						}
					}
			else if (pilih!=1 || pilih!=2) continue;
				}
			}
			if (pilih==2) {jumatkul=0; i=0;}
			if (jumatkul==0 && pilih == 2){
				
		system ("cls");
		title();
		cout << "Nama Mahasiswa : "; cin.ignore();
		cin.getline(nama,sizeof(nama));
	
		do{
			cout << "NIM : "; cin >> nim;
			system ("cls");
			title();
			cout << "Hallo " << nama;
	
	if (strlen(nim)!=9) cout << " maaf NIM anda salah" << endl;
		else if (nim[0]=='0' && nim[1]=='2' && nim[2]=='1')
		cout << " dari Prodi D3 Teknik Kimia\n";
			else if (nim[0]=='1' && nim[1]=='2' && nim[2]=='1')
			cout << " dari Prodi S1 Teknik Kimia\n";
				else if (nim[0]=='1' && nim[1]=='2' && nim[2]=='2')
				cout << " dari Prodi S1 Teknik Industri\n";
					else if (nim[0]=='1' && nim[1]=='2' && nim[2]=='3')
					cout << " dari Prodi S1 Teknik Informatika\n";
						else if (nim[0]=='1' && nim[1]=='2' && nim[2]=='4')
						cout << " dari Prodi S1 Sistem Informasi\n"; 
							else cout << " maaf NIM anda salah" << endl;
							}
		while(strlen(nim)!=9 || (nim[0]!='0'&&nim[0]!='1') || (nim[1]!='2') ||
		 (nim[2]!='1'&&nim[2]!='2'&&nim[2]!='3'&&nim[2]!='4'));
			  
			cout << "No Absen : " << nim[6] << nim[7] << nim[8];
			cout << "\nAngkatan : 20" << nim[3] << nim[4];
		}	
			if (jumatkul==0){
			cout << "\n\nInput Jumlah Mata Kuliah : "; cin >> jumatkul; }
	do{
		do{
			hadir[i]=1; phadir[i]=0; quiz[i]=-1; aktif[i]=-1; 
			tugas[i]=-1; uts[i]=-1; uas[i]=-1;
		
			cout << endl << i+1 << ". Nama Mata Kuliah: "; cin.ignore();
			cin.getline(matkul[i], sizeof(matkul[i]));
			cout << "   " << setfill('-') << setw(30) << "-" << endl;
		
			while (hadir[i]>phadir[i]){
				cout << endl << "   Kehadiran\t\t\t: "; cin >> hadir[i];
				cout << "   Total pertemuan 1 semester\t: "; cin >> phadir[i]; 
				if (hadir[i]>phadir[i]){
				cout << "   Kehadiran tidak boleh lebih besar daripada total pertemuan!\n";}
				}
			absen[i]=hadir[i]/phadir[i];
			cout << "\n   Persentase kehadiranmu\t: " << absen[i]*100 << " %";
			if(absen[i]>=0.85)
			cout << "\n   Kamu dapat mengikuti UAS "<< matkul[i] << endl;
			else cout << "\n   Kamu tidak dapat mengikuti UAS "<< matkul[i] << endl;
		
			do {
			while (quiz[i]>100 || quiz[i]<0){
			cout << endl << "   Nilai Quiz\t\t\t: "; cin >> quiz[i];
			if (quiz[i]>100){
				cout << "   Nilai terlalu besar!\n"; continue;}
				else if (quiz[i]<0){
					cout << "   Nilai terlalu kecil!\n"; continue;} }
			cout << "   Quiz digunakan berapa(%)\t: "; cin >> pquiz[i];
		
			while (aktif[i]>100 || aktif[i]<0){
			cout << endl << "   Nilai Keaktifan\t\t: "; cin >> aktif[i];
			if (aktif[i]>100){
				cout << "   Nilai terlalu besar!\n"; continue;}
				else if (aktif[i]<0){
					cout << "   Nilai terlalu kecil!\n"; continue;} }
			cout << "   Keaktifan digunakan berapa(%): "; cin >> paktif[i];
		
			while (tugas[i]>100 || tugas[i]<0){
			cout << endl << "   Nilai Tugas\t\t\t: "; cin >> tugas[i];
			if (tugas[i]>100){
				cout << "   Nilai terlalu besar!\n"; continue;}
				else if (tugas[i]<0){
					cout << "   Nilai terlalu kecil!\n"; continue;} }
			cout << "   Tugas digunakan berapa(%)\t: "; cin >> ptugas[i];
		
			while (uts[i]>100 || uts[i]<0){
			cout << endl << "   Nilai UTS\t\t\t: "; cin >> uts[i];
			if (uts[i]>100){
				cout << "   Nilai terlalu besar!\n"; continue;}
				else if (uts[i]<0){
					cout << "   Nilai terlalu kecil!\n"; continue;} }
			cout << "   UTS digunakan berapa(%)\t: "; cin >> puts[i];
		
			while (uas[i]>100 || uas[i]<0){
			if (absen[i]<0.85){
			uas[i]=0;
			cout << endl << "   Nilai UAS\t\t\t: " << uas[i] << endl;}
			else{
			cout << endl << "   Nilai UAS\t\t\t: "; cin >> uas[i];
			if (uas[i]>100){
				cout << "   Nilai terlalu besar!\n"; continue;}
				else if (uas[i]<0){
					cout << "   Nilai terlalu kecil!\n"; continue;} }}
			cout << "   UAS digunakan berapa(%)\t: "; cin >> puas[i];
		
			ptotal[i]=pquiz[i]+paktif[i]+ptugas[i]+puts[i]+puas[i];
			if (ptotal[i] < 100){
			cout << "   " << setfill('-') << setw(30) << "-" << endl;
			cout << "   Kriteria penilaian belum mencapai 100% atau = ";
			cout << ptotal[i] << "%" << endl;
			cout << "   Inputkan tepat 100%" << endl;
			}
			else if (ptotal[i] > 100){
				cout << "   " << setfill('-') << setw(30) << "-" << endl;
				cout << "   Kriteria penilaian melebihi 100% atau = ";
				cout << ptotal[i] << "%" << endl;
				cout << "   Inputkan tepat 100%" << endl;
			}
				else {cout << "\n   Kriteria penilaian sudah 100%\n";
					 cout << "   " << setfill('-') << setw(30) << "-" << endl;
				 }
					 }
			while (ptotal[i] !=100);
		
			akhir[i]=(quiz[i]*(pquiz[i]/100))+(aktif[i]*(paktif[i]/100))+
				 (tugas[i]*(ptugas[i]/100))+(uts[i]*(puts[i]/100))+
				 (uas[i]*(puas[i]/100));
		
			if (absen[i]<0.85) grade[i]="E*";		 
			else if (akhir[i]>=85) grade[i]="A";
				else if (akhir[i]>=80) grade[i]="A-";
					else if (akhir[i]>=75) grade[i]="B+";
						else if (akhir[i]>=70) grade[i]="B";
							else if (akhir[i]>=65) grade[i]="B-";
								else if (akhir[i]>=60) grade[i]="C+";
									else if (akhir[i]>=55) grade[i]="C";
										else if (akhir[i]>=45) grade[i]="D";
											else grade[i]="E";
										
			i++;
			} while(i<jumatkul);
		cout << "\n   Ingin menambah mata kuliah (y/n)? "; cin >> yn;
		if (yn=='y' || yn=='Y') jumatkul=jumatkul+1;
		} while(yn=='y' || yn=='Y');
	
	break;
	
		case 2: system ("cls");
				title();
	
	//Output
	system ("cls");
	title();
	
	cout << "Daftar Nilai "<< nama << endl;

	//Tabel Nilai
	cout << setfill('-') << setw(70) << "-" << endl ;
	cout << "       Nama				Nilai				\n";
	cout << "No.    Mata  	---------------------------------------------	Grade" << endl;
	cout << "      Kuliah    Quiz	Aktif	Tugas	UTS	UAS	Akhir	" << endl;
	cout << setfill('-') << setw(70) << "-" << endl ;
	for(int i=0; i<jumatkul; i++){
	cout << i+1 << ".  ";
	if (strlen(matkul[i])>10){
		for (int j=0; j<10; j++){
			cout << matkul[i][j];} }
			
	else if (strlen(matkul[i])<4){
		for (int j=0; j<4; j++){
			cout << matkul[i][j];} cout << setfill(' ') << setw(4) << " ";}
			
	else cout << matkul[i];
	cout << "	 " << setfill(' ') << setw(3) << quiz[i];
	cout << "	 " << setfill(' ') << setw(3) << aktif[i];
	cout << "	 " << setfill(' ') << setw(3) << tugas[i];
	cout << "	" << setfill(' ') << setw(3) << uts[i];
	cout << "	" << setfill(' ') << setw(3) << uas[i];
	cout << "	 " << setfill(' ') << setw(4) << akhir[i];
	cout << "	 " << grade[i];
	cout << endl;
}
	cout << setfill('-') << setw(70) << "-" << endl << endl;
	
	cout << "Ingin lihat keterangan nilai (y/n)? "; cin >> yn;
	if (yn=='y' || yn=='Y'){
		
		int y; //berfungsi untuk perulangan
		do{
			y=0; //untuk perulangan
			cout << endl <<"Keterangan nilai mata kuliah ke- ? "; cin>>a;
			
			if (a>jumatkul || a<1) {cout << "\nTidak ada mata kuliah" << endl;
				cout << setfill('-') << setw(30) << "-" << endl;}
				
			else {
				a=a-1;
				cout << endl;
				cout << matkul[a] << endl;
				cout << setfill('-') << setw(30) << "-" << endl;
				cout << "Kehadiran\t= " << absen[a]*100 << "%\n";
				cout << "Nilai Quiz\t= " << quiz[a];
				cout << " x " << pquiz[a] << "%\t= " << setfill(' ') << setw(2) << quiz[a]*(pquiz[a]/100) << endl;
				cout << "Nilai Keaktifan\t= " << aktif[a];
				cout << " x " << paktif[a] << "%\t= " << setfill(' ') << setw(2) << aktif[a]*(paktif[a]/100) << endl;
				cout << "Nilai Tugas\t= " << tugas[a];
				cout << " x " << ptugas[a] << "%\t= " << setfill(' ') << setw(2) << tugas[a]*(ptugas[a]/100) << endl;
				cout << "Nilai UTS\t= " << uts[a];
				cout << " x " << puts[a] << "%\t= " << setfill(' ') << setw(2) << uts[a]*(puts[a]/100) << endl;
				cout << "Nilai UAS\t= " << uas[a];
				cout << " x " << puas[a] << "%\t= " << setfill(' ') << setw(2) << uas[a]*(puas[a]/100) << endl;
				cout << "\t\t\t\t" << setfill('-') << setw(10) << " +" << endl;
				cout << "Nilai Akhir\t\t\t= " << akhir[a] << endl;
				cout << "Grade\t\t= " << grade[a] << endl;
				cout << setfill('-') << setw(30) << "-" << endl;
				
				if (absen[a]<0.85){
					cout << "Maaf " << nama << ", kamu BELUM LULUS /atau harus mengulang";
					cout << endl << "Semangat, kamu harus lebih rajin dan kamu pasti bisa!";
					cout << endl << "Lebih rajin mengikuti kuliah agar grademu tidak E*!\n";}
				else if (grade[a]=="A"){
					cout << "Selamat " << nama << ", kamu LULUS sangat memuaskan!";
					cout << endl << "Pertahankan prestasimu!" << endl;}
				else if (grade[a]<"C"){
					cout << "Selamat " << nama << ", kamu LULUS dengan baik!";
					cout << endl << "Tingkatkan prestasimu!" << endl;}
				else if (grade[a]<"D"){
					cout << "Selamat " << nama << ", kamu LULUS dengan nilai cukup!";
					cout << endl << "Lebih rajin dan tingkatkan prestasimu!\n";}
				else if (grade[a]<"E"){
					cout << nama << ", kamu lulus namun kami menyarankan untuk mengulang";
					cout << endl << "Semangat, lebih rajin dan perbaiki nilai\n";}
				else {cout << "Maaf " << nama << ", kamu BELUM LULUS /atau harus mengulang";
					cout << endl << "Semangat, kamu harus lebih rajin dan kamu pasti bisa!\n";}}
				
			while(y!=1 && y!=2){
				cout << endl << "Lihat keterangan nilai lagi? \n";
				cout << "1. Ya\n2. Tidak\n";
				cout << "Pilih: ";cin >> y;
				if(y<1 || y>2) {cout << "Input salah!"; continue;}}}
			while(y==1);
			
			}
			break;
		
		case 0: exit(0);
			
		default: system("cls");
				 main();
	
		} 
		cout << endl << endl << setfill('-') << setw(30) << '-';
		cout << "\nIngin kembali ke menu (y/n)? "; cin >> yn;
	} 
	while (yn=='y' || yn=='Y');
}
