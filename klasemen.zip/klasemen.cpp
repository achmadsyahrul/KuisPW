#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iomanip>
#include <fstream>

using namespace std;

typedef struct
{
	int main, search, seqsearch, seq_blmurut, seq_urut, sortby, order, sorting, binary, transaksi;
} pilih;
pilih menu;

typedef struct
{
	int masuk, kemasukan, selisih;
} goal;

typedef struct
{
	char nama_klub[20], negara[20];
	int tanding, menang, seri, kalah, poin;
	goal gol;
}data;
data klasemen[20];

typedef struct
{
	int home, away, match, round, nround;
}roundrobin;
roundrobin rr;

FILE *fk, *fn, *fha, *fs;
//fk = file klasemen, struct klasemen
//fn = sub file, int nteam dan int recent round
//fha = sub file, char home away

ofstream f_klasemen, f_sort, f_split, f_merge;

char file_utama[20], file_csv[20], file_sort[2][20];
char file_n[20] = {'n','_','\0'};
char file_ha[20] = {'h','a','_','\0'};
char txt[] = ".txt"; char csv[] = ".csv";
int nteam=0, r_round=0;
string yn, back, loop;

void input_data(), jadwal();
void round_robin(int i, int j);
void update(), reset();
void searching(), seqSearch(), seqSearch_BlmUrut(), seqSearch_Urut(), binary_search();
void sortby(), order(), filesort();
void sorting(), bubble_sort(), straight_insertion_sort(), selection_sort(), shell_sort();
void merge(int low, int high, int mid), merge_sort(int low, int high), quick_sort(int first, int last);
void transaksi(), bukafile();

int main()
{
	menu.main=0;
	do{
		bukafile();
		do{
			back="n"; loop="n"; //agar tidak otomatis mengulang program
			system("cls");
			cout << setw(50) << setfill('=') << "=" << endl;
			cout << '|' << setw(11) << setfill(' ') << " ";
			cout << "PROGRAM KLASEMEN SEPAK BOLA"<< setw(11) << setfill(' ') << '|' << endl;
			cout << setw(50) << setfill('=') << "=" << endl;
			cout <<"Menu :\n";
			cout << "1. Input Data\n";
			cout << "2. Searching\n";
			cout << "3. Transaksi\n";
			cout << "4. Exit File " << file_utama << endl;
			cout << "5. Exit Program\n";
			cout << "Pilih : "; cin >> menu.main;
			switch (menu.main)
			{
				case 1: 
				input_data();
				break;
				
				case 2:
				if(nteam>1)
					searching();
				else
					cout << "Belum ada data\n";
				break;
				
				case 3:
				transaksi();
				break;
				
				case 4:
				loop="ya";
				yn="n";
				break;
				
				case 5:
				exit(0);
				break;
				
				default:
				cout << "Pilihan menu tidak ada.\n";
				system("pause");
				loop="y";
			
			}
			if(back=="n" && loop=="n"){ //pilihan kembali ke menu utama
				do{
					cout << "Apakah ingin kembali ke menu utama?(y/n) : "; cin >> yn;
				}while((yn!="y" && yn !="Y") && (yn !="n" && yn!="N"));
			}
			if(back=="y" || loop=="y") yn="y"; //agar otomatis mengulang tanpa input
		}while(yn=="y"||yn=="Y");
	}while(loop=="ya");
}

void input_data()
{
	char ya;
	bool found;
	system("cls");
	if(nteam==0){
		do{
			cout << setw(51) << setfill('=') << "=" << endl;
			cout << '|' << setw(18) << setfill(' ') << " ";
			cout << "INPUT DATA TEAM"<< setw(18) << setfill(' ') << '|' << endl;
			cout << setw(51) << setfill('=') << "=" << endl;
			cout << "Banyaknya team: "; cin >> nteam;
			if(nteam<2)
				cout << "Banyak team harus lebih dari 1\n";
		}while(nteam<2);
		fn=fopen(file_n,"wb");
		putw(nteam,fn); //menyimpan jumlah team sesuai input user 
		putw(r_round,fn); //menyimpan recent round = 0
		fclose(fn);
		
		fk=fopen(file_utama,"wb");
		cin.ignore();
		for (int i=0; i<nteam; i++)
		{
			cout << "Data ke-"<<i+1 << endl;
			do{ 
				found = false;
				cout << "Nama Klub : ";
				cin.getline(klasemen[i].nama_klub,sizeof(klasemen[i].nama_klub));
				int j=0;
				while((j<i) & (!found)){
					if(strcmp(klasemen[j].nama_klub,klasemen[i].nama_klub)==0)
						found= true;
					else
						j++;
				}
				if(found)
					cout << "Nama klub harus berbeda.\n";
			}while(found);
			cout << "Negara : ";
			cin.getline(klasemen[i].negara,sizeof(klasemen[i].negara));
		}
		fwrite(&klasemen,sizeof(klasemen),1,fk);
		fclose(fk);
	}
	if((fha=fopen(file_ha,"rb"))==NULL){
		fha = fopen(file_ha, "wb");
		do{
			cout << "Pertandingan Home & Away? (y/n): "; cin >> ya;
		}while((ya!='y' && ya !='Y') && (ya !='n' && ya!='N')); 
		fputc(ya,fha);
		fclose(fha);
	}
	jadwal();
	update();
	f_klasemen.open(file_csv);
	f_klasemen << "No,Nama Klub,Negara,Tanding,Menang,Seri,Kalah,GM,GK,SG,Poin" << endl;
	for(int i=0; i<nteam; i++)
	{
		f_klasemen << i+1 << ',' << klasemen[i].nama_klub << ',' << klasemen[i].negara << ','
		<< klasemen[i].tanding << ',' << klasemen[i].menang << ',' << klasemen[i].seri << ','
		<< klasemen[i].kalah << ',' << klasemen[i].gol.masuk << ',' << klasemen[i].gol.kemasukan
		<< ',' << klasemen[i].gol.selisih << ',' << klasemen[i].poin << endl;
	}
	f_klasemen.close();
	
}

void jadwal()
{
	system("cls");
	char ya;
	cout << setw(50) << setfill('=') << "=" << endl;
	cout << '|' << setw(15) << setfill(' ') << " ";
	cout << "JADWAL PERTANDINGAN"<< setw(15) << setfill(' ') << '|' << endl;
	cout << setw(50) << setfill('=') << "=" << endl;
	fk=fopen(file_utama,"rb");
	fread(&klasemen,sizeof(klasemen),1,fk);
	fclose(fk);
	menu.sortby=1; menu.order=1;
	quick_sort(0,nteam-1);//sorting untuk jadwal
	fk=fopen(file_utama,"wb");
	fwrite(&klasemen,sizeof(klasemen),1,fk);
	fclose(fk);
	reset();
	
	rr.match = nteam/2;
	if(nteam%2==0)
		rr.round = nteam-1;
	else{
		rr.round = nteam;
		rr.match=rr.match+1;
		//klasemen[team].nama_klub = "Bye";
	}
	rr.nround=rr.round;
	fha = fopen(file_ha,"r");
	ya = getc(fha);
	if(ya=='Y' || ya=='y') 
		rr.nround=rr.nround*2;
	fclose(fha);
	for (int i=0; i<rr.nround; i++){
		cout << "Putaran ke-" << i+1 << endl;
		for (int j=0; j<rr.match; j++){
			round_robin(i,j);
			if(nteam%2==0 || (nteam%2==1 && j!=0))
			cout << klasemen[rr.home].nama_klub << " vs " << klasemen[rr.away].nama_klub << endl;
		}
		cout << endl;
	}
}

void round_robin(int i, int j)
{
	if(i<rr.round){
		if(nteam%2==0){
			if (j==0) 
				rr.home=0;
			else if (j+i>rr.round) 
				rr.home =(j+i+1)%nteam;
			else
				rr.home = (j+i)%nteam;
			
			if (rr.round-j+i>rr.round)
				rr.away= (rr.round-j+i+1)%nteam;
			else
				rr.away = (rr.round-j+i)%nteam;
		}
		else{
			rr.home = (j+i)%nteam;
			if (j==0) 
				rr.away=nteam;
			else
				rr.away = (rr.round-j+i)%nteam;
		}
			
	}
	else{
		if(nteam%2==0){
			if (j==0) 
				rr.away=0;
			else if (j+i>rr.round){
				rr.away =(j+i+1)%nteam;
				if (j+i+1>=nteam*2)
				rr.away = (j+i+2)%nteam;
			}
			else
				rr.away = (j+i)%nteam;
				
			if (rr.round-j+i>rr.round){
				rr.home= (rr.round-j+i+1)%nteam;
				if(rr.round-j+i+1>=nteam*2)
					rr.home = (rr.round-j+i+2)%nteam;
			}
				
			else
				rr.home = (rr.round-j+i)%nteam;
		}
		else{
			rr.away = (j+i)%nteam;
			if (j==0) 
				rr.home=nteam;
			else
				rr.home = (rr.round-j+i)%nteam;
		}
	}
}

void update()
{
	int golhome,golaway;
	fn=fopen(file_n,"rb");
	yn="y";
	nteam = getw(fn);
	r_round = getw(fn);
	fclose(fn);
	while((yn=="y" || yn=="Y") && r_round < rr.nround){
		do{
			cout << "Masukkan hasil pertandingan putaran ke-" << r_round+1 << "? (y/n): ";
			cin >> yn;
		}while((yn!="y" && yn !="Y") && (yn !="n" && yn!="N"));
		if(yn=="y" || yn=="Y"){
			do{
				cout << "\nPutaran ke-" << r_round+1 << endl;
					for (int i=0; i<rr.match; i++){
						round_robin(r_round,i);
						if(nteam%2==0 || (nteam%2==1 && i!=0)){
							cout << klasemen[rr.home].nama_klub << " vs " << klasemen[rr.away].nama_klub << endl;
							cout << "Masukkan gol " << klasemen[rr.home].nama_klub << " : "; cin >> golhome;
							cout << "Masukkan gol " << klasemen[rr.away].nama_klub << " : "; cin >> golaway;
							
							klasemen[rr.home].gol.masuk = klasemen[rr.home].gol.masuk + golhome;
							klasemen[rr.away].gol.masuk = klasemen[rr.away].gol.masuk + golaway;
						
							klasemen[rr.home].gol.kemasukan = klasemen[rr.home].gol.kemasukan + golaway;
							klasemen[rr.away].gol.kemasukan = klasemen[rr.away].gol.kemasukan + golhome;
						
							klasemen[rr.home].gol.selisih = klasemen[rr.home].gol.masuk - klasemen[rr.home].gol.kemasukan;
							klasemen[rr.away].gol.selisih = klasemen[rr.away].gol.masuk - klasemen[rr.away].gol.kemasukan;
						
							if(golhome > golaway){
								klasemen[rr.home].menang=klasemen[rr.home].menang+1;
								klasemen[rr.away].kalah=klasemen[rr.away].kalah+1;
								klasemen[rr.home].poin= klasemen[rr.home].poin + 3;
							}
							else if (golhome < golaway){
								klasemen[rr.away].menang=klasemen[rr.away].menang+1;
								klasemen[rr.home].kalah=klasemen[rr.home].kalah+1;
								klasemen[rr.away].poin= klasemen[rr.away].poin + 3;
							}
							else{
								klasemen[rr.home].seri=klasemen[rr.home].seri+1;
								klasemen[rr.away].seri=klasemen[rr.away].seri+1;
								klasemen[rr.home].poin= klasemen[rr.home].poin + 1;
								klasemen[rr.away].poin= klasemen[rr.away].poin + 1;
							}
							klasemen[rr.home].tanding=klasemen[rr.home].tanding+1;
							klasemen[rr.away].tanding=klasemen[rr.away].tanding+1;
						}
						cout << endl;
					}
				cout << endl;
				do{
					cout << "Apakah input gol sudah benar?(y/n) : "; cin >> yn;
				}while((yn!="y" && yn !="Y") && (yn !="n" && yn!="N"));
				if (yn=="n" || yn=="N")
					reset();
			}while(yn=="n" || yn=="N");
			r_round++;
			fk=fopen(file_utama,"wb"); //mungkin nanti akan diganti file update jika menu 3 sudah dibuat
			fwrite(&klasemen,sizeof(klasemen),1,fk);
			fclose(fk);
			fn=fopen(file_n,"wb");
			putw(nteam,fn); //menyimpan jumlah team sesuai input user 
			putw(r_round,fn); //menyimpan recent round = recent round +1
			fclose(fn);
		}
	} //berhenti ketika recent round >= n round / jumlah putaran
}

void searching()
{
	do{
		back="n"; loop="n";
		system("cls");
		cout << setw(49) << setfill('=') << "=" << endl;
		cout << '|' << setw(17) << setfill(' ') << " ";
		cout << "MENU SEARCHING"<< setw(17) << setfill(' ') << '|' << endl;
		cout << setw(49) << setfill('=') << "=" << endl;
		cout << "1. Sequential Search\n";
		cout << "2. Binary Search\n";
		cout << "3. Menu Utama\n";
		cout << "Pilih: "; cin>> menu.search;
		switch(menu.search)
		{
			case 1: 
			seqSearch();
			if(back=="y")
				loop="y";
			break;
			
			case 2:
			binary_search();
			break;
			
			case 3:
			back="y";
			break;
			
			default:
			cout << "Pilihan menu tidak ada.\n";
			system("pause");
			loop="y";
		}
		if(back=="n" && loop=="n"){
			do{
				cout << "Apakah ingin kembali ke menu searching?(y/n) : "; cin >> yn;
			}while((yn!="y" && yn !="Y") && (yn !="n" && yn!="N"));
		}
		
		if(loop=="y")
			yn="y";
		else if(back=="y")
			yn="n";
	}while(yn=="y"||yn=="Y");
}

void seqSearch()
{
	do{
		back="n"; loop="n";
		system("cls");
		cout << setw(50) << setfill('=') << " " << endl;
		cout << '|' << setw(13) << setfill(' ') << " ";
		cout << "MENU SEQUENTIAL SEARCH"<< setw(13) << setfill(' ') << '|' << endl;
		cout << setw(50) << setfill('=') << " " << endl;
		cout << "1. Sequential Search Belum Urut Non Sentinel\n";
		cout << "2. Sequential Search Belum Urut Sentinel\n";
		cout << "3. Sequential Search Urut Non Sentinel\n";
		cout << "4. Sequential Search Urut Sentinel\n";
		cout << "5. Menu Searching\n";
		cout << "Pilih: "; cin >> menu.seqsearch;
		switch(menu.seqsearch)
		{
			case 1: 
			seqSearch_BlmUrut();
			if(back=="y")
				loop="y";
			break;
			case 2:
			seqSearch_BlmUrut();
			if(back=="y")
				loop="y";
			break;
			case 3:
			seqSearch_Urut();
			menu.seqsearch=0, menu.seq_blmurut=0;
			break;
			case 4:
			seqSearch_Urut();
			menu.seqsearch=0, menu.seq_blmurut=0;
			break;
			case 5:
			back="y";
			break;
			default:
			cout << "Pilihan menu tidak ada.\n";
			system("pause");
			loop="y";
		}
		if(loop=="n" && back=="n"){
			do{
				cout << "Apakah ingin kembali ke menu sequential search?(y/n) : ";
				cin >> yn;
			}while((yn!="y" && yn !="Y") && (yn !="n" && yn!="N"));
		}
		if(loop=="y")
			yn="y";
		else if(back=="y")
			yn="n";
	}while(yn=="y" || yn=="Y");
}

void seqSearch_BlmUrut()
{
	int i, j, temu, ketemu[nteam+1], bawah, atas;
	char cari[20];
	bool found;
	do{
		system("cls");
		i=0, j=0, temu=0; loop="n"; back="n";
		found = false;
		cout << setw(50) << setfill('=') << " " << endl;
		cout << '|' << setw(16) << setfill(' ') << " ";
		cout << "CARI BERDASARKAN"<< setw(16) << setfill(' ') << '|' << endl;
		cout << setw(50) << setfill('=') << " " << endl;
		cout << "1. Nama klub\n";
		cout << "2. Negara\n";
		cout << "3. Rentang poin\n";
		cout << "4. Menu Sequential Search\n";
		cout << "Pilih: "; cin >> menu.seq_blmurut;
		cout << endl;
		switch(menu.seq_blmurut)
		{
			case 1:
			cout << "Masukkan nama klub yang dicari: ";
			cin.ignore(); cin.getline(cari,sizeof(cari));
			if (menu.seqsearch==2) 
				strcpy(klasemen[nteam].nama_klub,cari);
			while((i<=nteam) && (!found))
			{
				if(strcmp(klasemen[i].nama_klub,cari) == 0)
					found = true;
				else
					i = i + 1;
			}
			if(i<nteam && found)
			{
				cout << "\nNama Klub	: " << klasemen[i].nama_klub << endl;
				cout << "Negara		: " << klasemen[i].negara << endl;
				cout << "Poin		: " << klasemen[i].poin << endl << endl;
			}
			else
				cout << "\nNama klub " << cari << " tidak ditemukan\n\n";
			break;
		
			case 2: 
			cout << "Masukkan negara yang dicari: ";
			cin.ignore(); cin.getline(cari,sizeof(cari));
			if (menu.seqsearch==2) 
				strcpy(klasemen[nteam].negara,cari);
			while(i<=nteam)
			{
				if(strcmp(klasemen[i].negara,cari) == 0){
					if(i<nteam){
						ketemu[j]=i;
						temu++; j++;
					}
				}
				i++;
			}
			if(temu==0)
				cout << "\nKlub dengan negara " << cari << " tidak ditemukan\n";
			else{
				cout << "\nData yang ditemukan ada " << temu << endl << endl;
				for(i=0; i<temu; i++){
					cout << "Nama Klub	: " << klasemen[ketemu[i]].nama_klub << endl;
					cout << "Negara		: " << klasemen[ketemu[i]].negara << endl;
					cout << "Poin		: " << klasemen[ketemu[i]].poin << endl << endl;
				}
			}
			break;
		
			case 3:
			do{
				cout << "Masukkan batas bawah poin: "; cin >> bawah;
				cout << "Masukkan batas atas poin: "; cin >> atas;
				if(bawah>atas){
					cout << "Batas bawah harus lebih kecil atau sama dengan batas atas.\n";
				}
			}while(bawah>atas);
			if (menu.seqsearch==2)
				klasemen[nteam].poin = bawah;
			while(i<=nteam)
			{
				if(klasemen[i].poin >= bawah && klasemen[i].poin <= atas){
					if(i<nteam){
						ketemu[j]=i;
						temu++; j++;
					}
				}
				i++;
			}
			if(temu==0)
				cout << "\nKlub dengan rentang poin " << bawah << " - " << atas << " tidak ditemukan\n";
			else{
				cout << "\nData yang ditemukan ada " << temu << endl << endl;
				for(i=0; i<temu; i++){
					cout << "Nama Klub	: " << klasemen[ketemu[i]].nama_klub << endl;
					cout << "Negara		: " << klasemen[ketemu[i]].negara << endl;
					cout << "Poin		: " << klasemen[ketemu[i]].poin << endl << endl;
				}
			}
			break;
			
			case 4:
			back="y";
			break;
			
			default: 
			cout << "Pilihan menu tidak ada. \n";
			system("pause");
			loop="y";
		}
		if(back=="n" && loop=="n"){
			do{
				cout << "Apakah ingin kembali ke menu ";
				if (menu.seqsearch==1)
					cout << "sequential search belum urut non sentinel?(y/n) : ";
				else
					cout << "sequential search belum urut sentinel?(y/n) : ";
				cin >> yn;
			}while((yn!="y" && yn !="Y") && (yn !="n" && yn!="N"));
		}
		if(back=="y")
			yn="n";
		else if(loop=="y")
			yn="y";
	}while(yn=="y" || yn=="Y");
	
}

void seqSearch_Urut()
{
	yn="n"; //berhubungan dengan case 1 yang menggunakan cin.ignore()
	sorting();
	int i, j, temu, ketemu[nteam+1], bawah, atas;
	char cari[20];
	bool found;
	do{
		i=0, j=0, temu=0, yn="n", loop="n";
		found = false;
		cout << setw(50) << setfill('=') << " " << endl;
		cout << '|' << setw(16) << setfill(' ') << " ";
		cout << "CARI BERDASARKAN"<< setw(16) << setfill(' ') << '|' << endl;
		cout << setw(50) << setfill('=') << " " << endl;
		cout << "1. Nama klub\n";
		cout << "2. Negara\n";
		cout << "3. Rentang poin\n";
		cout << "Pilih: "; cin >> menu.seq_urut;
		cout << endl;
		switch(menu.seq_urut)
		{
			case 1:
			if(menu.sortby!=1){
				cout << "Data belum urut secara nama. Tidak dapat mencari nama klub.\n";
				do{
					cout << "Ingin mengurutkan data secara nama sekarang? (y/n): ";
					cin >> yn;
				}while((yn!="y" && yn !="Y") && (yn !="n" && yn!="N"));
				if(yn=="y" || yn=="Y")
					sorting();
				else
					break;
			}
			cout << "Masukkan nama klub yang dicari: ";
			if(yn=="n") 
				cin.ignore();
			cin.getline(cari,sizeof(cari));
			if (menu.seqsearch==4) 
				strcpy(klasemen[nteam].nama_klub,cari);
			if (menu.order==1){
				while((i<=nteam) && (!found) && strcmp(klasemen[i].nama_klub,cari)<=0)
				{
					if(strcmp(klasemen[i].nama_klub,cari) == 0)
						found = true;
					else
						i = i + 1;
				}
			}
			else{
				while((i<=nteam) && (!found) && strcmp(klasemen[i].nama_klub,cari)>=0)
				{
					if(strcmp(klasemen[i].nama_klub,cari) == 0)
						found = true;
					else
						i = i + 1;
				}
			}
			
			if(i<nteam && found)
			{
				cout << "\nNama Klub	: " << klasemen[i].nama_klub << endl;
				cout << "Negara		: " << klasemen[i].negara << endl;
				cout << "Poin		: " << klasemen[i].poin << endl << endl;
			}
			else
				cout << "\nNama klub " << cari << " tidak ditemukan\n\n";
			break;
			
			case 2:
			cout << "Masukkan negara yang dicari: ";
			cin.ignore(); cin.getline(cari,sizeof(cari));
			if (menu.seqsearch==4) 
				strcpy(klasemen[nteam].negara,cari);
			while(i<=nteam)
			{
				if(strcmp(klasemen[i].negara,cari) == 0){
					if(i<nteam){
						ketemu[j]=i;
						temu++; j++;
					}
				}
				i++; 
			}
			if(temu==0)
				cout << "\nKlub dengan negara " << cari << " tidak ditemukan\n";
			else{
				cout << "\nData yang ditemukan ada " << temu << endl << endl;
				for(i=0; i<temu; i++){
					cout << "Nama Klub	: " << klasemen[ketemu[i]].nama_klub << endl;
					cout << "Negara		: " << klasemen[ketemu[i]].negara << endl;
					cout << "Poin		: " << klasemen[ketemu[i]].poin << endl << endl;
				}
			}
			break;
			
			case 3:
			do{
				cout << "Masukkan batas bawah poin: "; cin >> bawah;
				cout << "Masukkan batas atas poin: "; cin >> atas;
				if(bawah>atas){
					cout << "Batas bawah harus lebih kecil atau sama dengan batas atas.\n";
				}
			}while(bawah>atas);
			if (menu.seqsearch==4)
				klasemen[nteam].poin = bawah;
			while(i<=nteam)
			{
				if(klasemen[i].poin >= bawah && klasemen[i].poin <= atas){
					if(i<nteam){ 		//if(i<nteam)
						ketemu[j]=i;	//ketemu[j]=i;
						temu++; j++;
					}				//temu++; i++; j++;
				}
				i++;
			}
			//if (menu.seqsearch==2) temu=temu-1; //XXX
			if(temu==0)
				cout << "\nKlub dengan rentang poin " << bawah << " - " << atas << " tidak ditemukan\n";
			else{
				cout << "\nData yang ditemukan ada " << temu << endl << endl;
				for(i=0; i<temu; i++){
					cout << "Nama Klub	: " << klasemen[ketemu[i]].nama_klub << endl;
					cout << "Negara		: " << klasemen[ketemu[i]].negara << endl;
					cout << "Poin		: " << klasemen[ketemu[i]].poin << endl << endl;
				}
			}
			break;
			
			default:
			cout << "Pilihan menu tidak ada.\n";
			system("pause");
			loop="y";
		}
		if(loop=="n"){
			do{
				cout << "Apakah ingin kembali ke menu ";
				if (menu.seqsearch==3)
					cout << "sequential search urut non sentinel?(y/n) : ";
				else
					cout << "sequential search urut sentinel?(y/n) : ";
				cin >> yn;
			}while((yn!="y" && yn !="Y") && (yn !="n" && yn!="N"));
		}
		if(loop=="y")
			yn="y";
	}while(yn=="y" || yn=="Y");
	
}

void binary_search()
{
	yn="n"; //berhubungan dengan case 1
	sorting();
	int i, j, k, x, a, b, temu, ketemu[nteam], bawah, atas;
	char cari[20];
	bool found;
	do{
		i=0, j=nteam-1, temu=0, x=0, found = false, yn="n", loop="n";
		cout << setw(50) << setfill('=') << " " << endl;
		cout << '|' << setw(16) << setfill(' ') << " ";
		cout << "CARI BERDASARKAN"<< setw(16) << setfill(' ') << '|' << endl;
		cout << setw(50) << setfill('=') << " " << endl;
		cout << "1. Nama klub\n";
		cout << "2. Negara\n";
		cout << "3. Rentang poin\n";
		cout << "Pilih: "; cin >> menu.binary;
		cout << endl;
		switch(menu.binary)
		{
			case 1:
			if(menu.sortby!=1){
				cout << "Data belum urut secara nama. Tidak dapat mencari nama klub.\n";
				do{
					cout << "Ingin mengurutkan data secara nama sekarang? (y/n): ";
					cin >> yn;
				}while((yn!="y" && yn !="Y") && (yn !="n" && yn!="N"));
				if(yn=="y" || yn=="Y")
					sorting();
				else
					break;
			}
			cout << "Masukkan nama klub yang dicari: ";
			if(yn=="n") 
				cin.ignore();
			cin.getline(cari,sizeof(cari));
			while((!found) & (i <= j))
			{
				k = (i + j) / 2;
				if(strcmp(cari,klasemen[k].nama_klub)==0)
					found = true;
				else
				{
					if(strcmp(cari,klasemen[k].nama_klub)<0)
					j = k - 1; // i tetap
					else
					i = k + 1; // j tetap
				}
			}
			if(found)
			{
				cout << "\nNama Klub	: " << klasemen[k].nama_klub << endl;
				cout << "Negara		: " << klasemen[k].negara << endl;
				cout << "Poin		: " << klasemen[k].poin << endl << endl;
			}
			else
				cout << "\nNama klub " << cari << " tidak ditemukan\n\n";
			break;
			
			case 2:
			cout << "Masukkan negara yang dicari: ";
			cin.ignore(); cin.getline(cari,sizeof(cari));
			while(i<=j && !found)
			{
				k = (i + j) / 2;
				if(strcmp(cari,klasemen[k].negara)==0){
					temu++;
					ketemu[x]=k;
					a=k+1; b=k-1;
					x++;
					while(a<=j){
						if(strcmp(klasemen[k].negara,klasemen[a].negara)==0){
							temu++;
							ketemu[x]=a;
							x++;
						}
						a++;
					}
					while(b>=0){
						if(strcmp(klasemen[k].negara,klasemen[b].negara)==0){
							temu++;
							ketemu[x]=b;
							x++;
						}
						b--;
					}
					found = true;
				}
				else {
					if(menu.order==1){
						if(strcmp(cari,klasemen[k].negara)<0)
							j = k - 1; // i tetap
						else
							i = k + 1; // j tetap
					}
					else{
						if(strcmp(cari,klasemen[k].negara)>0)
							j = k - 1; // i tetap
						else
							i = k + 1; // j tetap
					}
				}
			}
			if(temu==0)
				cout << "\nKlub dengan negara " << cari << " tidak ditemukan\n";
			else{
				cout << "\nData yang ditemukan ada " << temu << endl << endl;
				for(i=0; i<temu; i++){
					cout << "Nama Klub	: " << klasemen[ketemu[i]].nama_klub << endl;
					cout << "Negara		: " << klasemen[ketemu[i]].negara << endl;
					cout << "Poin		: " << klasemen[ketemu[i]].poin << endl << endl;
				}
			}
			break;
			
			case 3:
			do{
				cout << "Masukkan batas bawah poin: "; cin >> bawah;
				cout << "Masukkan batas atas poin: "; cin >> atas;
				if(bawah>atas){
					cout << "Batas bawah harus lebih kecil atau sama dengan batas atas.\n";
				}
			}while(bawah>atas);
			while(i <= j && !found)
			{
				k = (i + j) / 2;
				
				if(klasemen[k].poin >= bawah && klasemen[k].poin <= atas){
					temu++;
					ketemu[x]=k;
					a=k; b=k;
					x++;
					while(a<j){
						if(klasemen[a+1].poin >= bawah && klasemen[a+1].poin <= atas){
							temu++;
							a++;
							ketemu[x]=a;
							x++;
						}
						else a++;
					}
					while(b>0){
						if(klasemen[b-1].poin >= bawah && klasemen[b-1].poin <= atas){
							temu++;
							b--;
							ketemu[x]=b;
							x++;
						}
						else b--;
					}
					found = true;
				}
				if(menu.order==1)
					j = k - 1; // i tetap
				else if(menu.order==2)
					i = k + 1; // j tetap
			}
			if(temu==0)
				cout << "\nKlub dengan rentang poin " << bawah << " - " << atas << " tidak ditemukan\n";
			else{
				cout << "\nData yang ditemukan ada " << temu << endl << endl;
				for(i=0; i<temu; i++){
					cout << "Nama Klub	: " << klasemen[ketemu[i]].nama_klub << endl;
					cout << "Negara		: " << klasemen[ketemu[i]].negara << endl;
					cout << "Poin		: " << klasemen[ketemu[i]].poin << endl << endl;
				}
			}
			break;
			
			default:
			cout << "Pilihan menu tidak ada.\n";
			system("pause");
			loop="y";
			
		}
		if(loop=="n"){
			do{
				cout << "Ingin mencari lagi dengan binary search?(y/n) : "; cin >> yn;
			}while((yn!="y" && yn !="Y") && (yn !="n" && yn!="N"));
		}
		if(loop=="y")
			yn="y";
	}while(yn=="y" || yn=="Y");
}

void sorting()
{
	do{
		loop="n";
		system("cls");
		cout << setw(50) << setfill('=') << " " << endl;
		cout << '|' << setw(17) << setfill(' ') << " ";
		cout << "METODE SORTING"<< setw(17) << setfill(' ') << '|' << endl;
		cout << setw(50) << setfill('=') << " " << endl;
		cout << "1. Bubble Sort\n";
		cout << "2. Selection Sort\n";
		cout << "3. Insertion Sort\n";
		cout << "4. Shell Sort\n";
		cout << "5. Merge Sort\n";
		cout << "6. Quick Sort\n";
		cout << "Pilih sorting : "; cin >> menu.sorting;
		switch(menu.sorting)
		{
			case 1:
			if(yn=="n") //ini untuk mengulang sorting byname di searching yang urut
				sortby();
			else
				menu.sortby=1; //ini untuk mengulang sorting byname di searching yang urut
			
			order();
			bubble_sort();
			cout << "\n=========================\n";
			cout << "- - - Hasil Sorting - - -";
			cout << "\n=========================\n\n";
			for(int i=0; i<nteam; i++){
				cout << "Nama Klub	: " << klasemen[i].nama_klub << endl;
				cout << "Negara		: " << klasemen[i].negara << endl;
				cout << "Poin		: " << klasemen[i].poin << endl << endl;
			}
			filesort();
			break;
			
			case 2:
			if(yn=="n") //ini untuk mengulang sorting byname di searching yang urut
				sortby();
			else
				menu.sortby=1; //ini untuk mengulang sorting byname di searching yang urut
			
			order();
			selection_sort();
			cout << "\n=========================\n";
			cout << "- - - Hasil Sorting - - -";
			cout << "\n=========================\n\n";
			for(int i=0; i<nteam; i++){
				cout << "Nama Klub	: " << klasemen[i].nama_klub << endl;
				cout << "Negara		: " << klasemen[i].negara << endl;
				cout << "Poin		: " << klasemen[i].poin << endl << endl;
			}
			filesort();
			break;
			
			case 3:
			if(yn!="y" || yn!="Y") //ini untuk mengulang sorting byname di searching yang urut
				sortby();
			else
				menu.sortby=1; //ini untuk mengulang sorting byname di searching yang urut
			
			order();
			straight_insertion_sort();
			cout << "\n=========================\n";
			cout << "- - - Hasil Sorting - - -";
			cout << "\n=========================\n\n";
			for(int i=0; i<nteam; i++){
				cout << "Nama Klub	: " << klasemen[i].nama_klub << endl;
				cout << "Negara		: " << klasemen[i].negara << endl;
				cout << "Poin		: " << klasemen[i].poin << endl << endl;
			}
			filesort();
			break;
			
			case 4:
			if(yn=="n") //ini untuk mengulang sorting byname di searching yang urut
				sortby();
			else
				menu.sortby=1; //ini untuk mengulang sorting byname di searching yang urut
			
			order();
			shell_sort();
			cout << "\n=========================\n";
			cout << "- - - Hasil Sorting - - -";
			cout << "\n=========================\n\n";
			for(int i=0; i<nteam; i++){
				cout << "Nama Klub	: " << klasemen[i].nama_klub << endl;
				cout << "Negara		: " << klasemen[i].negara << endl;
				cout << "Poin		: " << klasemen[i].poin << endl << endl;
			}
			filesort();
			break;
			
			case 5:
			if(yn=="n") //ini untuk mengulang sorting byname di searching yang urut
				sortby();
			else
				menu.sortby=1; //ini untuk mengulang sorting byname di searching yang urut
			
			order();
			if(menu.sortby==3){ //jika ingin mengurutkan berdasarkan sistem kompetisi
				menu.sortby=2; //maka urutkan berdasarkan poin dahulu
				merge_sort(0, nteam-1);
				menu.sortby=3; //urutkan berdasarkan selisih gol
				merge_sort(0, nteam-1);
				menu.sortby=4; //urutkan berdasarkan gol masuk
			}
			merge_sort(0, nteam-1);
			cout << "\n=========================\n";
			cout << "- - - Hasil Sorting - - -";
			cout << "\n=========================\n\n";
			for(int i=0; i<nteam; i++){
				cout << "Nama Klub	: " << klasemen[i].nama_klub << endl;
				cout << "Negara		: " << klasemen[i].negara << endl;
				cout << "Poin		: " << klasemen[i].poin << endl << endl;
			}
			filesort();
			break;
			
			case 6:
			if(yn=="n") //ini untuk mengulang sorting byname di searching yang urut
				sortby();
			else
				menu.sortby=1; //ini untuk mengulang sorting byname di searching yang urut
			
			order();
			if(menu.sortby==3){ //jika ingin mengurutkan berdasarkan sistem kompetisi
				menu.sortby=2; //maka urutkan berdasarkan poin dahulu
				quick_sort(0, nteam-1);
				menu.sortby=3; //urutkan berdasarkan selisih gol
				quick_sort(0, nteam-1);
				menu.sortby=4; //urutkan berdasarkan gol masuk
			}
			quick_sort(0, nteam-1);
			cout << "\n=========================\n";
			cout << "- - - Hasil Sorting - - -";
			cout << "\n=========================\n\n";
			for(int i=0; i<nteam; i++){
				cout << "Nama Klub	: " << klasemen[i].nama_klub << endl;
				cout << "Negara		: " << klasemen[i].negara << endl;
				cout << "Poin		: " << klasemen[i].poin << endl << endl;
			}
			filesort();
			break;
			
			default: 
			cout << "Pilihan menu tidak ada.\n";
			system("pause");
			loop="y";
		}
	}while(loop=="y");
}

void sortby()
{
	do{
		cout << "\nSorting berdasarkan:\n";
		cout << "1. Nama\n";
		cout << "2. Poin\n";
		cout << "3. Sistem Kompetisi\n";
		cout << "Pilih : "; cin >> menu.sortby;
	}while(menu.sortby<1 || menu.sortby>3);
}

void order()
{
	do{
		cout << "\nDiurutkan dari:\n";
		cout << "1. Kecil ke besar / ascending (naik)\n";
		cout << "2. Besar ke kecil/ descending (turun)\n";
		cout << "Pilih : "; cin >> menu.order;
	}while(menu.order!=1 && menu.order!=2);
}

void filesort()
{
	cout << "Masukkan nama file hasil sorting (tanpa format): ";
	cin.ignore(); cin.getline(file_sort[0],sizeof(file_sort[0]));
	strcpy(file_sort[1],file_sort[0]);
	strcat(file_sort[0],txt);
	strcat(file_sort[1],csv);
	fs=fopen(file_sort[0],"wb");
	fwrite(&klasemen,sizeof(klasemen),1,fk);
	fclose(fk);
	f_sort.open(file_sort[1]);
	f_sort << "Rank,Nama Klub,Negara,Tanding,Menang,Seri,Kalah,GM,GK,SG,Poin" << endl;
	for(int i=0; i<nteam; i++)
	{
		f_sort << i+1 << ',' << klasemen[i].nama_klub << ',' << klasemen[i].negara << ','
		<< klasemen[i].tanding << ',' << klasemen[i].menang << ',' << klasemen[i].seri << ','
		<< klasemen[i].kalah << ',' << klasemen[i].gol.masuk << ',' << klasemen[i].gol.kemasukan
		<< ',' << klasemen[i].gol.selisih << ',' << klasemen[i].poin << endl;
	}
	f_sort.close();
	cout << "File telah tersimpan.\n";
	system("pause");
	system("cls");
}

void bubble_sort()
{
	for(int i=0; i<nteam-1; i++) {
		for(int j=0; j<nteam-1-i; j++) {
			if(menu.sortby==1){//sortbyname
				if(menu.order==1){ //ascendingorder
					if(strcmp(klasemen[j].nama_klub,klasemen[j+1].nama_klub) > 0){
						swap(klasemen[j],klasemen[j+1]);
					}
				}
				else{ //descendingorder
					if(strcmp(klasemen[j].nama_klub,klasemen[j+1].nama_klub) < 0){
						swap(klasemen[j],klasemen[j+1]);
					}
				}
			}
			else if(menu.sortby==2){ //sortbypoints
				if(menu.order==1){ //ascendingorder
					if(klasemen[j].poin > klasemen[j+1].poin){
						swap(klasemen[j],klasemen[j+1]);
					}
				}
				else{ //descendingorder
					if(klasemen[j].poin < klasemen[j+1].poin){
						swap(klasemen[j],klasemen[j+1]);
					}
				}
			}
			else{ //sortbycompetitionsystem
				if(menu.order==1){ //ascendingorder
					if(i==0 && j==0)
					{
						menu.sortby=2; //urutkan berdasarkan poin dahulu
						bubble_sort(); 
						menu.sortby=3;
					}
					if(klasemen[j].poin == klasemen[j+1].poin){
						if(klasemen[j].gol.selisih > klasemen[j+1].gol.selisih)
							swap(klasemen[j],klasemen[j+1]);
						
						else if(klasemen[j].gol.selisih == klasemen[j+1].gol.selisih){
							if(klasemen[j].gol.masuk > klasemen[j+1].gol.masuk)
								swap(klasemen[j],klasemen[j+1]);
						}
					}
				}
				else{ //descendingorder
					if(i==0 && j==0)
					{
						menu.sortby=2; //urutkan berdasarkan poin dahulu
						bubble_sort(); 
						menu.sortby=3;
					}
					if(klasemen[j].poin == klasemen[j+1].poin){
						if(klasemen[j].gol.selisih < klasemen[j+1].gol.selisih)
							swap(klasemen[j],klasemen[j+1]);
						
						else if(klasemen[j].gol.selisih == klasemen[j+1].gol.selisih){
							if(klasemen[j].gol.masuk < klasemen[j+1].gol.masuk)
								swap(klasemen[j],klasemen[j+1]);
						}
					}
				}
			}
		}
	}
}

void selection_sort()
{
	for(int i=0; i<nteam; i++){		
		for(int j=i+1; j<nteam; j++){
			if(menu.sortby==1){//sortbyname
				if(menu.order==1){//ascendingorder
					if(strcmp(klasemen[i].nama_klub,klasemen[j].nama_klub) > 0){
						swap(klasemen[i],klasemen[j]);
					}
				}
				else{//descendingorder
					if(strcmp(klasemen[i].nama_klub,klasemen[j].nama_klub) < 0){
						swap(klasemen[i],klasemen[j]);
					}
				}
			}
			else if(menu.sortby==2){//sortbypoints
				if(menu.order==1){//ascendingorder
					if(klasemen[i].poin > klasemen[j].poin){
						swap(klasemen[i],klasemen[j]);
					}
				}
				else{//descendingorder
					if(klasemen[i].poin < klasemen[j].poin){
						swap(klasemen[i],klasemen[j]);
					}
				}
			}
			else{ //sortbycompetitionsystem
				if(menu.order==1){ //ascendingorder
					if(i==0 && j==1)
					{
						menu.sortby=2; //urutkan berdasarkan poin dahulu
						selection_sort();
						menu.sortby=3; 
					}
					if(klasemen[i].poin == klasemen[j].poin){
						if(klasemen[i].gol.selisih > klasemen[j].gol.selisih)
						swap(klasemen[i],klasemen[j]);
					}
					if(klasemen[i].gol.selisih == klasemen[j].gol.selisih && klasemen[i].poin == klasemen[j].poin){
						if(klasemen[i].gol.masuk > klasemen[j].gol.masuk)
						swap(klasemen[i],klasemen[j]);
					}
				}
				else{ //descendingorder
					if(i==0 && j==1)
					{
						menu.sortby=2; //urutkan berdasarkan poin dahulu
						selection_sort(); 
						menu.sortby=3;
					}
					if(klasemen[i].poin == klasemen[j].poin){
						if(klasemen[i].gol.selisih < klasemen[j].gol.selisih)
						swap(klasemen[i],klasemen[j]);
					}
					if(klasemen[i].gol.selisih == klasemen[j].gol.selisih && klasemen[i].poin == klasemen[j].poin){
						if(klasemen[i].gol.masuk < klasemen[j].gol.masuk)
						swap(klasemen[i],klasemen[j]);
					}
				}
			}
		}
	}
}

void straight_insertion_sort()
{
	int j;
	for(int i=1; i<nteam; i++) {
		j = i - 1;
		if(menu.sortby==1){//sortbyname
			if(menu.order==1){//ascendingorder
				while((strcmp(klasemen[i].nama_klub,klasemen[j].nama_klub) < 0) & (j >= 0))
				{
					swap(klasemen[i],klasemen[j]);
					j--; i--;
				}
			}
			else{ //descendingorder
				while((strcmp(klasemen[i].nama_klub,klasemen[j].nama_klub) > 0) & (j >= 0))
				{
					swap(klasemen[i],klasemen[j]);
					j--; i--;
				}
			}
		}
		else if(menu.sortby==2){//sortbypoints
			if(menu.order==1){//ascendingorder
				while((klasemen[i].poin < klasemen[j].poin) & (j >= 0))
				{
					swap(klasemen[i],klasemen[j]);
					j--; i--;
				}
			}
			else{ //descendingorder
				while((klasemen[i].poin > klasemen[j].poin) & (j >= 0))
				{
					swap(klasemen[i],klasemen[j]);
					j--; i--;
				}
			}
		}
		else{ //sortbycompetitionsystem
			if(menu.order==1){ //ascendingorder
				if(i==1 && j==0)
				{
					menu.sortby=2; //urutkan berdasarkan poin dahulu
					straight_insertion_sort(); 
					menu.sortby=3;
				}
				if(klasemen[i].poin == klasemen[j].poin){
					while((klasemen[i].gol.selisih < klasemen[j].gol.selisih) & (j >= 0))
					{
						swap(klasemen[j+1],klasemen[j]);
						j--; i--;
					}
				}
				if(klasemen[i].gol.selisih == klasemen[j].gol.selisih && klasemen[i].poin == klasemen[j].poin){
					while((klasemen[i].gol.masuk < klasemen[j].gol.masuk) & (j >= 0))
					{
						swap(klasemen[j+1],klasemen[j]);
						j--; i--;
					}
				}
			}
			else{ //descendingorder
				if(i==1 && j==0)
				{
					menu.sortby=2; //urutkan berdasarkan poin dahulu
					straight_insertion_sort();
					menu.sortby=3;
				}
				
				if(klasemen[i].poin == klasemen[j].poin){
					while((klasemen[i].gol.selisih > klasemen[j].gol.selisih) & (j >= 0))
					{
						swap(klasemen[j+1],klasemen[j]);
						j--; i--;
					}
				}
				if(klasemen[i].gol.selisih == klasemen[j].gol.selisih && klasemen[i].poin == klasemen[j].poin){
					while((klasemen[i].gol.masuk > klasemen[j].gol.masuk) & (j >= 0))
					{
						swap(klasemen[j+1],klasemen[j]);
						j--; i--;
					}
				}
			}
		}
	}
}

void shell_sort(){
	for(int i = nteam/2; i > 0; i /= 2){
		for(int j = i; j < nteam; j++){
			for(int k = j-i; k >= 0; k -= i){
				if(menu.sortby==1){//sortbyname
					if(menu.order==1){//ascendingorder
						if(strcmp(klasemen[k+i].nama_klub,klasemen[k].nama_klub) < 0){
							swap(klasemen[k],klasemen[k+1]);
						}
					}
					else{//descendingorder
						if(strcmp(klasemen[k+i].nama_klub,klasemen[k].nama_klub) > 0){
							swap(klasemen[k],klasemen[k+1]);
						}
					}
				}
				else if(menu.sortby==2){//sortbypoint
					if(menu.order==1){//ascendingorder
						if(klasemen[k+i].poin < klasemen[k].poin){
							swap(klasemen[k],klasemen[k+1]);
						}
					}
					else{//descendingorder
						if(klasemen[k+i].poin > klasemen[k].poin){
							swap(klasemen[k],klasemen[k+1]);
						}
					}
				}
				else{ //sortbycompetitionsystem
					if(menu.order==1){ //ascendingorder
						if(i==nteam/2 && j==nteam/2)
						{
							menu.sortby=2; //urutkan berdasarkan poin dahulu
							shell_sort(); 
							menu.sortby=3;
						}
						if(klasemen[k+1].poin == klasemen[k].poin){
							if(klasemen[k+1].gol.selisih < klasemen[k].gol.selisih)
							swap(klasemen[k],klasemen[k+1]);
						}
						if(klasemen[k+1].gol.selisih == klasemen[k].gol.selisih && klasemen[k+1].poin == klasemen[k].poin){
							if(klasemen[k+1].gol.masuk < klasemen[k].gol.masuk)
							swap(klasemen[k],klasemen[k+1]);
						}
					}
					else{ //descendingorder
						if(i==nteam/2 && j==nteam/2)
						{
							menu.sortby=2; //urutkan berdasarkan poin dahulu
							shell_sort(); 
							menu.sortby=3;
						}
						
						if(klasemen[k+1].poin == klasemen[k].poin){
							if(klasemen[k+1].gol.selisih > klasemen[k].gol.selisih)
							swap(klasemen[k],klasemen[k+1]);
						}
						if(klasemen[k+1].gol.selisih == klasemen[k].gol.selisih && klasemen[k+1].poin == klasemen[k].poin){
							if(klasemen[k+1].gol.masuk > klasemen[k].gol.masuk)
							swap(klasemen[k],klasemen[k+1]);
						}
					}
				}
			}
		}
	}	
}

void merge(int low, int high, int mid)
{
	// We have low to mid and mid+1 to high already sorted.
	int i, j, k, s;
	data tempr[high-low+1];
	i = low;
	k = 0;
	j = mid + 1;
	s=mid+1;
 
	// Merge the two parts into temp[].
	
	while (i <= mid && j <= high && s<= high)
	{
		if(menu.sortby==1){//sortbyname
			if(menu.order==1){//ascendingorder
				if (strcmp(klasemen[i].nama_klub,klasemen[j].nama_klub) < 0)
				{
					tempr[k] = klasemen[i];
					k++;
					i++;
				}
				else
				{
					tempr[k] = klasemen[j];
					k++;
					j++;
				}
			}
			else{//descendingorder
				if (strcmp(klasemen[i].nama_klub,klasemen[j].nama_klub) > 0)
				{
					tempr[k] = klasemen[i];
					k++;
					i++;
				}
				else
				{
					tempr[k] = klasemen[j];
					k++;
					j++;
				}
			}
		}
		else if(menu.sortby==2){//sortbypoints
			if(menu.order==1){//ascendingorder
				if (klasemen[i].poin < klasemen[j].poin)
				{
					tempr[k] = klasemen[i];
					k++;
					i++;
				}
				else
				{
					tempr[k] = klasemen[j];
					k++;
					j++;
				}
			}
			else{//descendingorder
				if (klasemen[i].poin > klasemen[j].poin)
				{
					tempr[k] = klasemen[i];
					k++;
					i++;
				}
				else
				{
					tempr[k] = klasemen[j];
					k++;
					j++;
				}
			}
		}
		else if(menu.sortby==3){ //sortbycompetitionsystem
			if(menu.order==1){ //ascendingorder
				if(klasemen[i].poin == klasemen[j].poin){
					if (klasemen[i].gol.selisih < klasemen[j].gol.selisih)
					{
						tempr[k] = klasemen[i];
						k++;
						i++;
					}
					else
					{
						tempr[k] = klasemen[j];
						k++;
						j++;
					}
				}
				else{
					s++;
				}
			}
			else{ //descendingorder
				if(klasemen[i].poin == klasemen[j].poin){
					if (klasemen[i].gol.selisih > klasemen[j].gol.selisih)
					{
						tempr[k] = klasemen[i];
						k++;
						i++;
					}
					else
					{
						tempr[k] = klasemen[j];
						k++;
						j++;
					}
				}
				else{
					s++;
				}
			}
		}
		else{//sortbycompetitionsystem
			if(menu.order==1){ //ascendingorder
				if (klasemen[i].gol.selisih == klasemen[j].gol.selisih && klasemen[i].poin == klasemen[j].poin){
					if (klasemen[i].gol.masuk < klasemen[j].gol.masuk)
					{
						tempr[k] = klasemen[i];
						k++;
						i++;
					}
					else
					{
						tempr[k] = klasemen[j];
						k++;
						j++;
					}
				}
				else{
					s++;
				}
			}
			else{//descendingorder
				if (klasemen[i].gol.selisih == klasemen[j].gol.selisih && klasemen[i].poin == klasemen[j].poin){
					if (klasemen[i].gol.masuk > klasemen[j].gol.masuk)
					{
						tempr[k] = klasemen[i];
						k++;
						i++;
					}
					else
					{
						tempr[k] = klasemen[j];
						k++;
						j++;
					}
				}
				else{
					s++;
				}	
			}
		}
	}
 
	while (i <= mid)
	{
		tempr[k] = klasemen[i];
		k++;
		i++;
	}
 
	while (j <= high)
	{
		tempr[k] = klasemen[j];
		k++;
		j++;
	}
 
	for (i = low; i <= high; i++)
	{
		klasemen[i] = tempr[i-low];
	}
}

void merge_sort(int low, int high) //(0, n-1)
{
	int mid;
	if (low < high)
	{
		mid=(low+high)/2;
		// Split data menjadi 2 bagian
		merge_sort(low, mid);
		merge_sort(mid+1, high);

		// Merge 
		merge(low, high, mid);
	}
}

void quick_sort(int first, int last) //(0, n-1)
{
	int low, high,l_separator, sg_separat, gm_separat;
	char list_separator[20];
	low = first;
	high = last;
	strcpy(list_separator,klasemen[(first+last)/2].nama_klub); //list_separator = klasemen[(first + last) / 2].nama_klub;
	l_separator=klasemen[(first+last)/2].poin;
	sg_separat=klasemen[(first+last)/2].gol.selisih;
	gm_separat=klasemen[(first+last)/2].gol.masuk;
	do {
		if(menu.sortby==1){//sortbyname
			if(menu.order==1){//ascendingorder
				while(strcmp(klasemen[low].nama_klub,list_separator) < 0)
				low++;
				while(strcmp(klasemen[high].nama_klub,list_separator) > 0)
				high--;
			}
			else{//descendingorder
				while(strcmp(klasemen[low].nama_klub,list_separator) > 0)
				low++;
				while(strcmp(klasemen[high].nama_klub,list_separator) < 0)
				high--;
			}
		}
		else if(menu.sortby==2){//sortbypoints
			if(menu.order==1){//ascendingorder
				while(klasemen[low].poin < l_separator)
				low++;
				while(klasemen[high].poin > l_separator)
				high--;
			}
			else{//descendingorder
				while(klasemen[low].poin > l_separator)
				low++;
				while(klasemen[high].poin < l_separator)
				high--;
			}
		}
		else if(menu.sortby==3){//sortbycompetitionsystem1
			if(menu.order==1){//ascendingorder
				if(klasemen[low].poin==klasemen[high].poin)
				{
					while(klasemen[low].gol.selisih < sg_separat)
					low++;
					while(klasemen[high].gol.selisih > sg_separat)
					high--;
				}
			}
			else{//descendingorder
				if(klasemen[low].poin==klasemen[high].poin)
				{
					while(klasemen[low].gol.selisih > sg_separat)
					low++;
					while(klasemen[high].gol.selisih < sg_separat)
					high--;
				}
			}
		}
		else if(menu.sortby==4){//sortbycompetitionsystem2
			if(menu.order==1){//ascendingorder
				if(klasemen[low].gol.selisih==klasemen[high].gol.selisih && klasemen[low].poin==klasemen[high].poin)
				{
					while(klasemen[low].gol.masuk < gm_separat)
					low++;
					while(klasemen[high].gol.masuk > gm_separat)
					high--;
				}
			}
			else{//descendingorder
				if(klasemen[low].gol.selisih==klasemen[high].gol.selisih && klasemen[low].poin==klasemen[high].poin)
				{
					while(klasemen[low].gol.masuk > gm_separat)
					low++;
					while(klasemen[high].gol.masuk < gm_separat)
					high--;
				}
			}
		}
		
		if(low <= high)
		{
			swap(klasemen[low],klasemen[high]);
			low++; high--;
		}
	} while(low <= high);
	if(first < high) quick_sort(first, high);
	if(low < last) quick_sort(low, last);
}

void transaksi()
{
	char file_split[20],file_split_csv[20];
	char split_file[20],split_file_csv[20];
	char jmls1[20]={'n','_','\0'};
	char jmls2[20]={'n','_','\0'};
	char file_merging[20];
	char hasil_merging[20],hasil_merging_csv[20];
	data spliting[2][20];
	data merging[20], temp_merge[20];
	
	jmls1[2]='\0';
	jmls2[2]='\0';
	int x,tot;
	
	FILE *split,*xfile,*fmerge;
	
	cout << "Menu Transaksi\n";
	cout << "1. Splitting\n";
	cout << "2. Merging Sambung\n";
	cout << "Pilih: "; cin >> menu.transaksi;
	switch(menu.transaksi)
	{
		case 1:
		cout << "\nFile 1 = " << file_utama << endl;
		cout << "Akan displit menjadi 2 file\n";
		cout << "\nMasukkan nama file 2 (tanpa format): "; cin.ignore();
		cin.getline(file_split,sizeof(file_split)); 
		strcpy(file_split_csv,file_split);
		strcat(file_split,txt);
		strcat(file_split_csv,csv);
		strcat(jmls1,file_split);
		cout << "Masukkan nama file 3 (tanpa format): ";
		cin.getline(split_file,sizeof(split_file));
		strcpy(split_file_csv,split_file);
		strcat(split_file,txt);
		strcat(split_file_csv,csv);
		strcat(jmls2,split_file);
		
		menu.sortby=3;
		menu.order=2;
		bubble_sort();
		
		x=0;
		split=fopen(file_split,"wb");
		xfile=fopen(jmls1,"wb");
		for(int i=0; i<nteam/2; i++){
			spliting[0][i]=klasemen[i];
			x=x+i;
		}
		fwrite(&spliting[0],sizeof(spliting[0]),1,split);
		putw(x,xfile);
		fclose(split);
		fclose(xfile);
		
		x=0;
		split=fopen(split_file,"wb");
		xfile=fopen(jmls2,"wb");
		for(int i=nteam/2; i<nteam; i++){
			spliting[1][i]=klasemen[i];
			x=x+i;
		}
		
		cout << "\n========================";
		cout << "\nHasil Split File : " << file_split;
		cout << "\n========================" << endl << endl;
		for(int i=0; i<nteam/2; i++){
			cout << "Nama Klub	: " << spliting[0][i].nama_klub << endl;
			cout << "Negara		: " << spliting[0][i].negara << endl;
			cout << "Poin		: " << spliting[0][i].poin << endl << endl;
		}
		cout << "\n========================";
		cout << "\nHasil Split File : " << split_file;
		cout << "\n========================" << endl << endl;
		for(int i=nteam/2; i<nteam; i++){
			cout << "Nama Klub	: " << spliting[1][i].nama_klub << endl;
			cout << "Negara		: " << spliting[1][i].negara << endl;
			cout << "Poin		: " << spliting[1][i].poin << endl << endl;
		}
		
		fwrite(&spliting[1],sizeof(spliting[1]),1,split);
		putw(x,xfile);
		fclose(split);
		fclose(xfile);
		
		f_split.open(file_split_csv);
		f_split << "No,Nama Klub,Negara,Tanding,Menang,Seri,Kalah,GM,GK,SG,Poin" << endl;
		for(int i=0; i<nteam/2; i++)
		{
			f_split << i+1 << ',' << klasemen[i].nama_klub << ',' << klasemen[i].negara << ','
			<< spliting[0][i].tanding << ',' << spliting[0][i].menang << ',' << spliting[0][i].seri << ','
			<< spliting[0][i].kalah << ',' << spliting[0][i].gol.masuk << ',' << spliting[0][i].gol.kemasukan
			<< ',' << spliting[0][i].gol.selisih << ',' << spliting[0][i].poin << endl;
		}
		f_split.close();
		
		f_split.open(split_file_csv);
		f_split << "No,Nama Klub,Negara,Tanding,Menang,Seri,Kalah,GM,GK,SG,Poin" << endl;
		for(int i=nteam/2; i<nteam; i++)
		{
			f_split << i+1 << ',' << spliting[1][i].nama_klub << ',' << spliting[1][i].negara << ','
			<< spliting[1][i].tanding << ',' << spliting[1][i].menang << ',' << spliting[1][i].seri << ','
			<< spliting[1][i].kalah << ',' << spliting[1][i].gol.masuk << ',' << spliting[1][i].gol.kemasukan
			<< ',' << spliting[1][i].gol.selisih << ',' << spliting[1][i].poin << endl;
		}
		f_split.close();
		
		break;
		
		case 2:
		cout << "\nFile 1 = " << file_utama << endl;
		cout << "Akan dimerging dengan file 2\n";
		cout << "\nMasukkan nama file 2 (tanpa format): "; cin.ignore();
		cin.getline(file_merging,sizeof(file_merging));
		strcat(file_merging,txt);
		strcat(jmls1,file_merging);
		
		cout << "Hasil merging akan disimpan di file 3\n";
		cout << "\nMasukkan nama file 3 (tanpa format): ";
		cin.getline(hasil_merging,sizeof(hasil_merging));
		strcpy(hasil_merging_csv,hasil_merging);
		strcat(hasil_merging,txt);
		strcat(hasil_merging_csv,csv);
		strcat(jmls2,hasil_merging);
		
		xfile=fopen(jmls1,"rb");
		x=getw(xfile);
		fclose(xfile);
		fmerge=fopen(file_merging,"rb");
		fread(&temp_merge,sizeof(temp_merge),1,fmerge);
		fclose(fmerge);
		
		tot=nteam+x;
		for(int i=0; i<nteam; i++){
			merging[i]=klasemen[i];
		}
		int j=0;
		for(int i=nteam; i<tot; i++){
			merging[i]=temp_merge[j];
			j++;
		}
		
		cout << "\n========================";
		cout << "\nHasil Merging : " << hasil_merging;
		cout << "\n========================" << endl << endl;
		for(int i=0; i<tot; i++){
			cout << "Nama Klub	: " << merging[i].nama_klub << endl;
			cout << "Negara		: " << merging[i].negara << endl;
			cout << "Poin		: " << merging[i].poin << endl << endl;
		}
	
		fmerge=fopen(hasil_merging,"wb");
		xfile=fopen(jmls2,"wb");
		fwrite(&merging,sizeof(merging),1,fmerge);
		putw(tot,xfile);
		putw(0,xfile);//recent round
		fclose(fmerge);
		fclose(xfile);
		
		f_merge.open(hasil_merging_csv);
		f_merge << "No,Nama Klub,Negara,Tanding,Menang,Seri,Kalah,GM,GK,SG,Poin" << endl;
		for(int i=0; i<tot; i++)
		{
			f_merge << i+1 << ',' << klasemen[i].nama_klub << ',' << klasemen[i].negara << ','
			<< merging[i].tanding << ',' << merging[i].menang << ',' << merging[i].seri << ','
			<< merging[i].kalah << ',' << merging[i].gol.masuk << ',' << merging[i].gol.kemasukan
			<< ',' << merging[i].gol.selisih << ',' << merging[i].poin << endl;
		}
		f_merge.close();
		
	}
}

void bukafile()
{
	file_n[2]='\0';
	file_ha[3]='\0';
	if(menu.main!=0) cin.ignore();
	system("cls");
	cout << setw(50) << setfill('=') << "=" << endl;
	cout << '|' << setw(20) << setfill(' ') << " ";
	cout << "BUKA FILE"<< setw(20) << setfill(' ') << '|' << endl;
	cout << setw(50) << setfill('=') << "=" << endl;
	cout << "Masukkan nama file (tanpa format file): ";
	cin.getline(file_utama,sizeof(file_utama));
	strcpy(file_csv,file_utama); //file csv = file utama
	strcat(file_utama,txt); //file_utama.txt
	strcat(file_csv,csv); //file_csv.csv
	strcat(file_n,file_utama); //file_n.txt
	strcat(file_ha,file_utama); //file_ha.txt
	
	if((fk=fopen(file_utama,"rb"))==NULL)
	{
		nteam=0; r_round=0;
		fk=fopen(file_utama,"wb");
		fclose(fk);
		fn=fopen(file_n,"wb");
		putw(nteam,fn);
		putw(r_round,fn);
		fclose(fn);
	}
	else
	{
		fread(&klasemen,sizeof(klasemen),1,fk);
		fclose(fk);
		fn=fopen(file_n,"rb");
		nteam = getw(fn);
		r_round = getw(fn);
		fclose(fn);
	}
}

void reset()
{
	if(r_round==0){
		for(int i=0; i<nteam; i++){
			klasemen[i].tanding=0;
			klasemen[i].menang=0;
			klasemen[i].seri=0;
			klasemen[i].kalah=0;
			klasemen[i].gol.masuk=0;
			klasemen[i].gol.kemasukan=0;
			klasemen[i].gol.selisih=0;
			klasemen[i].poin=0;
		}
	}
	else{
		fk=fopen(file_utama,"rb");
		fread(&klasemen,sizeof(klasemen),1,fk);
		fclose(fk);
	}
}
